import java.math.BigInteger;
public class Main {

    public static void main(String[] args) {
        Global.print("Execution Started");
        BigInteger n = new BigInteger("63133235398342558254366970933");
        BigInteger rootn = n.sqrt();

        int bsmooth = 50000;
        int SEIVE_LIMIT = 5000000;
        QuadraticSeive seive = new QuadraticSeive(n,rootn,bsmooth, SEIVE_LIMIT);

        Global.print("Execution Ended");
    }





}