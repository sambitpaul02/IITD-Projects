# InsecureBankv2 - Application Security Testing

## Overview
This project demonstrates the process of identifying and exploiting security vulnerabilities in a mobile application (InsecureBankv2), specifically focusing on the modification of client-side flags and bypassing application controls. The testing is based on a simulated Android environment where various tools and techniques are employed to explore and manipulate the app's security.

## Tools and Environment

The following tools and technologies were used in this project:

### 1. **Genymotion (Android Emulator)**
   - **Version**: Used to emulate Android devices for testing purposes.
   - **Description**: A powerful Android emulator used for testing the application in an isolated environment. It enables testing the behavior of the app on various Android versions and device configurations.

### 2. **Android Debug Bridge (ADB)**
   - **Version**: ADB is utilized to interact with the Android device from the host system.
   - **Description**: A command-line tool that allows you to communicate with an Android device. It is used to install APKs, interact with apps, read logs, and perform other tasks related to app testing.
   - **Commands Used**:
     - `adb install <apk>` – To install the APK on the emulator/device.
     - `adb uninstall <package>` – To uninstall the app from the emulator/device.
     - `adb logcat` – To monitor system logs for debugging and capturing sensitive information.

### 3. **APKTool**
   - **Version**: APKTool 2.5.0 or later.
   - **Description**: A tool for decompiling Android APK files into their source resources. It allows reverse engineering of Android applications and helps inspect the structure of the APK and modify its contents (e.g., modifying client-side flags or resources).
   - **Commands Used**:
     - `apktool d <apk-file> -o <output-folder>` – To decompile the APK and extract the resources.
     - `apktool b <output-folder> -o <new-apk>` – To rebuild the modified APK.
   
### 4. **Keytool and Jarsigner**
   - **Version**: Java Development Kit (JDK).
   - **Description**: These tools are used to generate a keystore, sign the modified APK, and ensure it can be installed on an Android device.
   - **Commands Used**:
     - `keytool -genkey -v -keystore testkey.keystore -alias testkey -keyalg RSA -keysize 2048 -validity 10000` – To generate a keypair and keystore.
     - `jarsigner -keystore testkey.keystore <apk-file> testkey` – To sign the APK after modifying it.

### 5. **SQLite3**
   - **Version**: SQLite 3.28.0.
   - **Description**: A C-language library that implements a small, fast, self-contained, high-reliability, full-featured SQL database engine. It is used for interacting with the app's local SQLite databases, where sensitive data might be stored.
   - **Commands Used**:
     - `sqlite3 <database-file>` – To open and query SQLite database files.
     - `select * from <table-name>;` – To fetch data from a specific table in the database.

### 6. **Frida (Dynamic Instrumentation Framework)**
   - **Version**: Frida 15.0.0 or later.
   - **Description**: A dynamic instrumentation framework used for intercepting and manipulating the behavior of applications at runtime. It can be used to inspect memory, modify app behavior, and extract sensitive information during execution.
   - **Commands Used**:
     - `frida -U -f <package-name> -l <script.js>` – To run Frida on an app and execute JavaScript code for dynamic analysis.
     - `frida -U -f <package-name> -p <process-id>` – To attach to an already running process for live instrumentation.

### 7. **WebView Chromium and WebView Manipulation**
   - **Description**: The app makes use of WebView for rendering web content. Analyzing and modifying WebView settings, such as disabling JavaScript, can prevent XSS (Cross-Site Scripting) attacks and other security issues when interacting with the app’s embedded web content.
   - **Files Involved**:
     - `WebViewChromiumPrefs.xml` (Shared Preferences)
     - `mySharedPreferences.xml` (Contains sensitive data like passwords or tokens).

### 8. **XSS Testing**
   - **Description**: Testing the app’s vulnerability to Cross-Site Scripting (XSS) attacks by injecting malicious scripts into web content loaded via WebView. This vulnerability allows an attacker to execute arbitrary JavaScript on the user's device.
   - **Evidence**: The app’s WebView component allowed for the execution of a malicious script leading to an alert popup.

## Application Vulnerabilities Explored

### 1. **Sensitive Information in Shared Preferences**
   - Shared Preferences are used to store sensitive user data like usernames, passwords, and tokens. The data is often stored in plaintext or weakly encrypted form, which can be exploited to extract sensitive information.
   - Tools like `adb`, `sqlite3`, and `Frida` were used to locate and dump the shared preferences and databases where sensitive information was stored.

### 2. **Client-Side Control Bypass**
   - The app allowed client-side flag manipulation through XML files (e.g., `strings.xml`) to bypass administrative controls, revealing unauthorized functionality like the "Create User" button.
   - Tools used: APKTool, ADB, Jarsigner for modifying and signing the APK.

### 3. **SQL Injection and Database Manipulation**
   - The app's local SQLite database (`mydb`) contained sensitive data, including usernames that could potentially be exploited by SQL Injection.
   - Tools like `sqlite3` were used to explore the local database and extract user information, indicating a lack of proper security mechanisms for protecting data in local storage.

### 4. **XSS (Cross-Site Scripting) via WebView**
   - XSS vulnerabilities were found by injecting malicious scripts into the app’s WebView component, leading to potential execution of arbitrary JavaScript on the user's device.
   - A screenshot and alert were triggered from a custom HTML file containing a malicious script.

## Conclusion

This project demonstrates various mobile app security vulnerabilities, including improper handling of sensitive data, client-side control manipulation, and exposure to XSS attacks. The outlined tools and techniques provide a foundation for testing and exploiting these vulnerabilities in Android applications. Proper mitigation strategies, including server-side validation, secure storage, and integrity checks, should be implemented to protect against such vulnerabilities.

---

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
