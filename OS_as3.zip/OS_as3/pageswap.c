#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "spinlock.h"
#include "sleeplock.h"
#include "fs.h"
#include "buf.h"
#include "pageswap.h"

// Swap slot array and adaptive parameters
struct swap_slot swap_slots[NSWAPSLOTS];
int Th = 100;
int Npg = 4;
int alpha = ALPHA;
int beta = BETA;

// Existing code from original swap.c
void swap_init(void) {
  for (int i = 0; i < NSWAPSLOTS; i++) {
    swap_slots[i].is_free = 1;
    swap_slots[i].page_perm = 0;
  }
  cprintf("Swap: Initialized %d swap slots\n", NSWAPSLOTS);
}

int swap_alloc(int perm) {
  for (int i = 0; i < NSWAPSLOTS; i++) {
    if (swap_slots[i].is_free) {
      swap_slots[i].is_free = 0;
      swap_slots[i].page_perm = perm;
      return i;
    }
  }
  return -1;
}

void swap_free(int slot_index) {
  if (slot_index < 0 || slot_index >= NSWAPSLOTS)
    panic("swap_free: invalid slot");
  swap_slots[slot_index].is_free = 1;
  swap_slots[slot_index].page_perm = 0;
}

void swap_write(int slot_index, void *page) {
  uint start_block = 2 + slot_index * BLOCKS_PER_PAGE;
  for (int i = 0; i < BLOCKS_PER_PAGE; i++) {
    struct buf *b = bread(0, start_block + i);
    memmove(b->data, (char*)page + i*BSIZE, BSIZE);
    bwrite(b);
    brelse(b);
  }
}

void swap_read(int slot_index, void *page) {
  uint start_block = 2 + slot_index * BLOCKS_PER_PAGE;
  for (int i = 0; i < BLOCKS_PER_PAGE; i++) {
    struct buf *b = bread(0, start_block + i);
    memmove((char*)page + i*BSIZE, b->data, BSIZE);
    brelse(b);
  }
}

extern struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

extern struct {
  struct spinlock lock;
  int use_lock;
  struct run *freelist;
  int free_pages;
} kmem;

// Helper function to invalidate TLB entry
void invlpg(uint va) {
  asm volatile("invlpg (%0)" : : "r" (va) : "memory");
}

// Find process with highest RSS (lowest PID if tie)
static struct proc* find_victim_process(void) {
  struct proc *p, *victim = 0;
  int max_rss = -1;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if(p->state != UNUSED && p->rss > max_rss) {
      max_rss = p->rss;
      victim = p;
    } else if(p->state != UNUSED && p->rss == max_rss) {
      if(victim && p->pid < victim->pid) {
        victim = p;
      }
    }
  }
  return victim;
}

// Find victim page in process address space
static pte_t* find_victim_page(struct proc *p) {
  pde_t *pgdir = p->pgdir;
  pte_t *pte, *fallback = 0;
  uint va;

  for(va = 0; va < KERNBASE; va += PGSIZE) {
    pte = walkpgdir(pgdir, (void*)va, 0);
    if(pte && (*pte & PTE_P)) {               // Page present
      if(!(*pte & PTE_A)) {                  // Preferred candidate
        return pte;
      } else {
        if(!fallback) fallback = pte;       // Remember first accessed page
        *pte &= ~PTE_A;                    // Clear accessed flag
      }
    }
  }
  return fallback; // Fallback to first accessed page
}

// Swap out a page from victim process
void swap_out(void) {
  struct proc *victim;
  pte_t *pte;
  uint pa, perm, slot;
  char *mem;

  // Find victim process
  if((victim = find_victim_process()) == 0)
    panic("swap_out: no victim process");


  // Find victim page
  if((pte = find_victim_page(victim)) == 0) {
    panic("swap_out: no victim page");
  }

  // Get physical address and permissions
  pa = PTE_ADDR(*pte);
  perm = (*pte & (PTE_U | PTE_W));

  // Allocate swap slot
  if((slot = swap_alloc(perm)) < 0) {
    panic("swap_out: no swap slots");
  }

  // Write page to swap
  mem = P2V(pa);
  swap_write(slot, mem);

  // Update PTE
  *pte = (slot << 12) | PTE_SWAP;
  //invlpg(PTE_ADDR(*pte));

  // Free physical page and update RSS
  kfree(mem);
  // victim->sz -= PGSIZE;
  victim->ms -= PGSIZE;

  victim->rss--;

}

// Handle page fault (swapped-in)
void handle_pgfault(pde_t *pgdir, uint va) {
  pte_t *pte = walkpgdir(pgdir, (void*)va, 0);
  if(!pte || !(*pte & PTE_SWAP))
    panic("handle_pgfault: invalid page fault");

  // Get swap slot from PTE
  int slot = (PTE_ADDR(*pte)) >> 12;

  // Allocate new page
  char *mem = kalloc();
  if(!mem) {
    // If allocation fails, try freeing more pages
    swap_out();
    mem = kalloc();
    if(!mem) panic("handle_pgfault: kalloc failed");
  }

  // Read from swap
  swap_read(slot, mem);

  // Update PTE and free swap slot
  *pte = V2P(mem) | PTE_P | swap_slots[slot].page_perm;
  //invlpg(va);
  swap_free(slot);

  // Update RSS for current process
  struct proc *curproc = myproc();
  // curproc->sz += PGSIZE;  // Add page size when swapping in
  curproc->ms += PGSIZE;
  curproc->rss++;
}

// void adaptive_swap(void) {
//   int current_free = kmem.free_pages;
//
//   if(current_free < Th) {
//     cprintf("Current_free = %d , Current Threshold = %d, Swapping %d pages\n", current_free, Th, Npg);
//
//     // Swap out Npg pages
//     for(int i = 0; i < Npg; i++) {
//       swap_out();
//     }
//
//     Th -= (Th * beta) / 100;
//     Npg += (Npg * alpha) / 100;
//
//     if (Npg >= LIMIT) {
//           Npg = LIMIT;
//     }
//   }
// }

void adaptive_swap(void) {
  int current_free = kmem.free_pages;

  if(current_free < Th) {
    cprintf("Current Threshold = %d, Swapping %d pages\n", Th, Npg);

    // Swap out Npg pages
    for(int i = 0; i < Npg; i++) {
      swap_out();
    }

    // Update Threshold
    //Th = Th * (100 - beta) / 100;
    Th -= (Th * beta) / 100;
    // Update Npg with upper limit
    //Npg = Npg * (100 + alpha) / 100;
    Npg += (Npg * alpha) / 100;
    if(Npg > LIMIT) Npg = LIMIT;

    // cprintf("Updated Threshold = %d , Updated Npg : %d \n", Th , Npg);
  }
}

