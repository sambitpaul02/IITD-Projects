#include "types.h"
#include "stat.h"
#include "user.h"

#define N 600   // Number of pages to allocate (tune for your RAM size and swap slot count)

char *pages[N];

int main() {
  printf(1, "swaptouch started, pid=%d\n", getpid());
  int i;

  // Allocate many pages and touch each
  for (i = 0; i < N; i++) {
    pages[i] = malloc(4096);
    if (!pages[i]) {
      printf(1, "malloc failed at %d\n", i);
      break;
    }
    pages[i][0] = i; // Touch to ensure page is mapped
  }
  printf(1, "Allocated and touched %d pages. Now looping and touching again...\n", i);

  int cnt = 0;
  while (1) {
    sleep(400);
    // Each loop, touch all pages to force swapping in
    for (int j = 0; j < i; j++) {
      pages[j][0] += 1;
    }
    printf(1, "Touched all %d pages (cnt=%d)\n", i, ++cnt);
    sleep(1000); // Gives you time to press Ctrl+I after swapping settles
  }

  exit();
}

