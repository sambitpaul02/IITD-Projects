#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"
#include "signal.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;

extern struct {
    struct spinlock lock;
    struct proc proc[NPROC];
} ptable;

// At boot time tvinit is called to initialise the IDT 

void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)  // SETGATE fill each IDT entry with a 
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);     // Definition of SETGATE is in x86.h
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{  
  if(tf->trapno == T_SYSCALL){
    if(myproc()->killed)
      exit();
    myproc()->tf = tf;
    syscall();
    if(myproc()->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpuid() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    
    // cprintf("Timer interrupt\n");
    
    // acquire(&ptable.lock);
     // if(myproc() && myproc()->state == SUSPENDED) {
      //  yield();
     // }
    // release(&ptable.lock);
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();   // defined inside kbd.c
    lapiceoi();  // defined inside lapic.c
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpuid(), tf->cs, tf->eip);
    lapiceoi();
    break;

  //PAGEBREAK: 13
  default:
    if(myproc() == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpuid(), tf->eip, rcr2());
      panic("trap");
    }
    
    //------------------ I am commenting the below part ( origional ) for no exit in control + G part ----------------------------------->
    
    
    
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",myproc()->pid, myproc()->name, tf->trapno,tf->err, cpuid(), tf->eip, rcr2());
    myproc()->killed = 1;
  }
  
  //------------------ I am commenting the above part ( origional ) for no exit in control + G part -------------------------------------->
  
  
  
  
  //---------------------------------------------------------------------------------------------------------------------->
  // int esp_val;
  // asm volatile("movl %%esp, %0" : "=r"(esp_val));
  // cprintf(1, "Handler ESP before: 0x%x\n", esp_val);
  
  // Check for pending signals
    if(myproc() && myproc()->pending_signals) {
        if(myproc()->pending_signals & (1 << (SIGCUSTOM - 1))) { // if (4th bit from LSB of the pending_signal is 1)
            if(myproc()->sighandler) {
                // Prepare to invoke the handler
                uint old_eip = tf->eip;
                uint *new_esp = (uint*)(tf->esp - 4);
                if(copyout(myproc()->pgdir, (uint)new_esp, (char*)&old_eip, 4) < 0) {
					cprintf("copyout is not successful , the process is going to be killed ");
                    myproc()->killed = 1;
                } else {
                    tf->esp = (uint)new_esp;
                    tf->eip = (uint)myproc()->sighandler;
                    cprintf("stack pointer value : %d",tf->esp);
                }
                myproc()->pending_signals &= ~(1 << (SIGCUSTOM - 1));
             
            }
        }
    }
    
  // asm volatile("movl %%esp, %0" : "=r"(esp_val));
  // cprintf(1, "Handler ESP after: 0x%x\n", esp_val);
    
   //--------------------------------------------------------------------------------------------------------------------->
	
	struct proc *p = 0; // shell
	
	for(p=&ptable.proc;p<&ptable.proc[NPROC];p++){
		if(p->pid == 2)
			break;
		}

   // In trap() before returning to user space
	if(myproc() && myproc()->pending_suspend) {
		acquire(&ptable.lock);
		myproc()->state = SUSPENDED;
		myproc()->pending_suspend = 0;
		sched();
		release(&ptable.lock);
		// cprintf("pid : %d I am suspended \n",myproc()->pid);
		wakeup(p);
	}
	
	//--------------------------------------------------------------------------------------------------------------------->
   
   
  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  struct proc *newp;
  static char *states[] = {
	  [UNUSED]    "unused",
	  [EMBRYO]    "embryo",
	  [SLEEPING]  "sleep ",
	  [RUNNABLE]  "runble",
	  [RUNNING]   "run   ",
	  [ZOMBIE]    "zombie",
	  [SUSPENDED] "suspended"
  };
  
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER){
	  
	  // for(newp=&ptable.proc;newp<&ptable.proc[NPROC];newp++)
		// cprintf("pid : %d , p->killed : %d , state : %s \n",newp->pid,newp->killed,states[p->state]);
	  // cprintf("pid : %d I am going to be killed\n",myproc()->pid);
	  exit();
	  }

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(myproc() && myproc()->state == RUNNING &&
     tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(myproc() && myproc()->killed && (tf->cs&3) == DPL_USER)
    exit();
}
