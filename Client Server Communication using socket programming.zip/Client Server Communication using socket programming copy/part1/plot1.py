import matplotlib.pyplot as plt

p = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
avg_time = [0.1, 0.07, 0.05, 0.038, 0.031, 0.027, 0.024, 0.021, 0.018, 0.015]

plt.plot(p, avg_time, marker='o')
plt.xlabel('P (No. of words in a packet)')
plt.ylabel('Average Time')
plt.title('P vs. Average Time')
plt.grid(True)
#plt.savefig('plot1.png')
plt.show()
