#include <iostream>
#include <winsock2.h>
#include <string>
#include <map>
#include <stdlib.h>
#include <stdio.h>

#include <vector>
#include <sstream>
//#include <chrono> Used for clock timing
#include "cJSON.h"


#pragma comment(lib, "ws2_32.lib")

using namespace std;


char* read_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* content = (char*)malloc(length + 1);
    fread(content, 1, length, file);
    content[length] = '\0';

    fclose(file);
    return content;
}

char* get_server_ip(cJSON* config_json) {
    cJSON* server_ip = cJSON_GetObjectItemCaseSensitive(config_json, "server ip");
    // if (cJSON_IsString(server_ip)) {}
    return server_ip->valuestring;
}

int get_server_port(cJSON* config_json) {
    cJSON* server_port = cJSON_GetObjectItemCaseSensitive(config_json, "server port");
    //if (cJSON_IsNumber(server_port)) {}
    return server_port->valueint;
}

int get_k(cJSON* config_json) {
    cJSON* k_value = cJSON_GetObjectItemCaseSensitive(config_json, "k");
    return k_value->valueint;

    //if (cJSON_IsNumber(k_value)) {}
}

int get_p(cJSON* config_json) {
    cJSON* p_value = cJSON_GetObjectItemCaseSensitive(config_json, "p");
    return p_value->valueint;


    //if (cJSON_IsNumber(p_value)) {}

}

int get_n(cJSON* config_json) {
    cJSON* n_value = cJSON_GetObjectItemCaseSensitive(config_json, "n");
    return n_value->valueint;
}

int send_the_string(string msg, SOCKET socket) {
    int return_value = send(socket, msg.c_str(), msg.length(), 0);
    return return_value;
}

int main() {

    const char* configfilename = "config.json";

    char* jsondata = read_file(configfilename);

    cJSON* configjson = cJSON_Parse(jsondata);

    char* server_ip = get_server_ip(configjson);
    int server_port = get_server_port(configjson);
    int k = get_k(configjson);
    int p = get_p(configjson);
    int n = get_n(configjson);



    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    int return_value;

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock" << endl;
        return 1;
    }

    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(server_ip);
    serverAddr.sin_port = htons(server_port);

    return_value = connect(clientSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr));


    string input;
    cout << "Enter the offset to be sent: ";
    cin >> input;
    input.push_back('\n');

    send_the_string(input, clientSocket);

    vector<string> client_words;
    char buffer[1024*1024];
    //auto start = std::chrono::high_resolution_clock::now();

    while (1) {
        int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);

        if (recvSize > 0) {

            buffer[recvSize] = '\0';

            string received_data(buffer);
            stringstream ss(received_data);
            string word;

            while (getline(ss, word, '\n')) {
                if (word == "$$" || word == "EOF") {
                    break;
                }
                client_words.push_back(word);
            }

            if (word == "$$" || word == "EOF") {
                break;
            }
        }
    }


    map<string, int> wordfreq;

    for (const string &word : client_words) {
        wordfreq[word]++;
    }

    for (const auto &freqmap : wordfreq) {
        cout << freqmap.first << ", " << freqmap.second << endl;
    }





    //auto end = std::chrono::high_resolution_clock::now();
    //std::chrono::duration<double> elapsed = end - start;
    //std::cout << "Time taken to execute the program: " << elapsed.count() << " seconds" << std::endl;

    return 0;

}
