import matplotlib.pyplot as plt

clients = [1, 4, 8, 12, 16, 20, 24, 28, 32]
completion_time = [0.08, 0.09, 0.12, 0.13, 0.13, 0.10, 0.12, 0.11, 0.1]

plt.plot(clients, completion_time, marker='o')
plt.xlabel('Concurrent Clients')
plt.ylabel('Avg Completion Time')
plt.title('Concurrent Clients vs. Avg Completion Time')
#plt.savefig('plot2.png')
plt.show()
