#include <iostream>
#include <winsock2.h>
#include <iostream>
#include <winsock2.h>
#include <string>
#include <map>
#include <vector>
#include <sstream>
#include <fstream>
#include "cJSON.h"
#include <pthread.h>

//g++ -o server_test.exe server_test.c cJSON.c -L/lib -lpthreadVC2 -I/include -I. -L. -lws2_32

#define BUFFER_SIZE 1024
char buffer[1024];

struct client_data {
    SOCKET clientSocket;
    int k;
    int p;
    char* filename;
};

#pragma comment(lib, "ws2_32.lib")

using namespace std;

char* read_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* content = (char*)malloc(length + 1);
    fread(content, 1, length, file);
    content[length] = '\0';

    fclose(file);
    return content;
}

char* get_server_ip(cJSON* config_json) {
    cJSON* server_ip = cJSON_GetObjectItemCaseSensitive(config_json, "server ip");
    // if (cJSON_IsString(server_ip)) {}
    return server_ip->valuestring;
}
char* get_filename(cJSON* config_json) {
    cJSON* fname = cJSON_GetObjectItemCaseSensitive(config_json, "filename");
    // if (cJSON_IsString(server_ip)) {}
    return fname->valuestring;
}

int get_server_port(cJSON* config_json) {
    cJSON* server_port = cJSON_GetObjectItemCaseSensitive(config_json, "server port");
    //if (cJSON_IsNumber(server_port)) {}
    return server_port->valueint;
}

int get_k(cJSON* config_json) {
    cJSON* k_value = cJSON_GetObjectItemCaseSensitive(config_json, "k");
    return k_value->valueint;

    //if (cJSON_IsNumber(k_value)) {}
}

int get_p(cJSON* config_json) {
    cJSON* p_value = cJSON_GetObjectItemCaseSensitive(config_json, "p");
    return p_value->valueint;


    //if (cJSON_IsNumber(p_value)) {}

}

int get_n(cJSON* config_json) {
    cJSON* n_value = cJSON_GetObjectItemCaseSensitive(config_json, "n");
    return n_value->valueint;
}


vector<string> getWordsFromFile(ifstream &file, int offset, int k) {
    file.clear();
    file.seekg(0, ios::beg);
    string line, word;
    vector<string> words;
    int no_of_words = 0; 

    
    getline(file, line);
    stringstream ss(line);

    
    while (getline(ss, word, ',')) {
        words.push_back(word);
        no_of_words++;
    }

    
    if (offset >= no_of_words) {
        return {};
    }

    
    vector<string> result;
    for (int i = offset; i < no_of_words && result.size() < k; ++i) {
        result.push_back(words[i]);
    }

    return result;
}



int receive_data_as_string( SOCKET clientSocket){

  int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
  if (recvSize > 0) {
      buffer[recvSize] = '\0';
      cout << "Received message: " <<buffer  << endl;
  } else if (recvSize == 0) {
      cout << "Client disconnected" << endl;
  } else {
      cerr << "Recv failed: " << WSAGetLastError() << endl;
  }

  return 0;
}
int receive_data( SOCKET clientSocket, char ending_char){

  int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
  if (recvSize > 0) {
      buffer[recvSize] = '\0';
      for (int i = 0; i < recvSize; ++i) {
            if (buffer[i] == ending_char) {
                buffer[i] = '\0';
                break;
            }
        }
      cout << "Received message: " <<buffer  << endl;
  }
  return 0;
}

void show_packet_cout(string x, int number){
  cout<<"-------------Packet "<<number<<"-------------\n"<<x<<endl<<"-----------------------------------"<<endl;
}
void show_packet_cout(string x){
  cout<<"-------------Packet-------------\n"<<x<<endl<<"--------------------------------"<<endl;
}

void serve_request(int offset_recieved_from_client, int k, int p, SOCKET clientSocket, char* filename_from_congif){
  ifstream file(filename_from_congif);


  vector<string> words = getWordsFromFile(file, offset_recieved_from_client, k);

  if (!words.empty()) {
      words.push_back("EOF\n");
  } else {
      words.push_back("$$\n");
  }

  vector<vector<string>> words_per_packet;

  for (size_t i = 0; i < words.size(); i += p) {
      vector<string> packet;

      for (size_t j = i; j < i + p && j < words.size(); j++) {
          packet.push_back(words[j]);
      }
      string packet_str = "";
      for (const string &word : packet) {
              packet_str += word + "\n";
      }
      show_packet_cout(packet_str);

      int sendResult = send(clientSocket, packet_str.c_str(), packet_str.length(), 0);

      words_per_packet.push_back(packet);
  }
}




void* handle_thread(void* client_info) {
    client_data* data = (client_data*)client_info;
    SOCKET clientSocket = data->clientSocket;
    int k = data->k;
    int p = data->p;
    char* filename_from_congif = data->filename;

    receive_data(clientSocket, '\n');
    int offset_received_from_client = atoi(buffer);

    serve_request(offset_received_from_client, k ,p, clientSocket, filename_from_congif) ;////////////


}


int main() {


    WSADATA wsaData;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrSize = sizeof(clientAddr);
    int bytesReceived;

    const char* configfilename = "config.json";

    char* jsondata = read_file(configfilename);

    cJSON* configjson = cJSON_Parse(jsondata);

    char* server_ip = get_server_ip(configjson);
    int server_port = get_server_port(configjson);
    int k = get_k(configjson);
    int p = get_p(configjson);
    int n = get_n(configjson);
    char* filename_from_congif = get_filename(configjson);



    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock: " << WSAGetLastError() << endl;
        return 1;
    }

    serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    cout << "Socket created successfully" << endl;

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(server_port);

    bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr));

    int listen_return_value = listen(serverSocket, 1);

    cout << "Listening..." << endl;

    while (true) {
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);

        cout << "Client connected" << endl;
        int recvSize;
        while (true) {

            // int offset_recieved_from_client = 0;
            //
            // receive_data(clientSocket, '\n');
            // offset_recieved_from_client = atoi(buffer);
            //
            // serve_request(offset_recieved_from_client, k ,p, clientSocket, filename_from_congif) ;////////////

            pthread_t thread_id;
            client_data* data = new client_data;
            data->clientSocket = clientSocket;
            data->k = k;
            data->p = p;
            data->filename = filename_from_congif;

            pthread_create(&thread_id, NULL, handle_thread, (void*)data);
            pthread_detach(thread_id);


            break;
        }
    }



    closesocket(clientSocket);
    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
