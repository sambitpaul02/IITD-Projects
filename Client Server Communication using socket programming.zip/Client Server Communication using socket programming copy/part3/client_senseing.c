#include <iostream>
#include <winsock2.h>
#include <cstring>
#include <thread>
#include <chrono>
#include "cJSON.h"

#pragma comment(lib, "ws2_32.lib")
#define BUFFER_SIZE 1024

using namespace std;

char* read_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* content = (char*)malloc(length + 1);
    fread(content, 1, length, file);
    content[length] = '\0';

    fclose(file);
    return content;
}
char* get_server_ip(cJSON* config_json) {
    cJSON* server_ip = cJSON_GetObjectItemCaseSensitive(config_json, "server ip");
    // if (cJSON_IsString(server_ip)) {}
    return server_ip->valuestring;
}
char* get_filename(cJSON* config_json) {
    cJSON* fname = cJSON_GetObjectItemCaseSensitive(config_json, "filename");
    // if (cJSON_IsString(server_ip)) {}
    return fname->valuestring;
}
int get_server_port(cJSON* config_json) {
    cJSON* server_port = cJSON_GetObjectItemCaseSensitive(config_json, "server port");
    //if (cJSON_IsNumber(server_port)) {}
    return server_port->valueint;
}
int get_k(cJSON* config_json) {
    cJSON* k_value = cJSON_GetObjectItemCaseSensitive(config_json, "k");
    return k_value->valueint;

    //if (cJSON_IsNumber(k_value)) {}
}
int get_p(cJSON* config_json) {
    cJSON* p_value = cJSON_GetObjectItemCaseSensitive(config_json, "p");
    return p_value->valueint;


    //if (cJSON_IsNumber(p_value)) {}

}
int get_n(cJSON* config_json) {
    cJSON* n_value = cJSON_GetObjectItemCaseSensitive(config_json, "n");
    return n_value->valueint;
}

int main() {

    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    char buffer[BUFFER_SIZE];

      const char* configfilename = "config.json";

      char* jsondata = read_file(configfilename);
      cJSON* configjson = cJSON_Parse(jsondata);

      char* server_ip = get_server_ip(configjson);
      int server_port = get_server_port(configjson);
      int k = get_k(configjson);
      int p = get_p(configjson);
      int n = get_n(configjson);
      char* filename_from_config = get_filename(configjson);



    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock: " << WSAGetLastError() << endl;
        return 1;
    }

    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSocket == INVALID_SOCKET) {
        cerr << "Socket creation failed: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(server_ip);
    serverAddr.sin_port = htons(server_port);

    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) != 0) {
        cerr << "Connection failed: " << WSAGetLastError() << endl;
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    while (true) {
        
        int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        if (recvSize <= 0) {
            cerr << "Failed to receive: " << WSAGetLastError() << endl;
            break;
        }
        buffer[recvSize] = '\0';
        cout << "Server Status: " << buffer;

        if (strncmp(buffer, "IDLE", 4) == 0) {
           
            string request = "Hello Server!\n";
            send(clientSocket, request.c_str(), request.length(), 0);
            break;
        } else {
            
            cout << "Server is busy, backing off..." << endl;
            Sleep(1); 
        }
    }

    closesocket(clientSocket);
    WSACleanup();
    string ext;
    cin>>ext;

    return 0;
}
