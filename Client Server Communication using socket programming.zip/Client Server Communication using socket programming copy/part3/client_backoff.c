#include <iostream>
#include <winsock2.h>
#include <cstdlib>
#include <ctime>
#include <string>
#include <chrono>
#include <thread>
#include <map>
#include <sstream>
#include "cJSON.h"

#pragma comment(lib, "ws2_32.lib")

using namespace std;

char* read_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* content = (char*)malloc(length + 1);
    fread(content, 1, length, file);
    content[length] = '\0';

    fclose(file);
    return content;
}

char* get_server_ip(cJSON* config_json) {
    cJSON* server_ip = cJSON_GetObjectItemCaseSensitive(config_json, "server ip");
    return server_ip->valuestring;
}

int get_server_port(cJSON* config_json) {
    cJSON* server_port = cJSON_GetObjectItemCaseSensitive(config_json, "server port");
    return server_port->valueint;
}

int get_k(cJSON* config_json) {
    cJSON* k_value = cJSON_GetObjectItemCaseSensitive(config_json, "k");
    return k_value->valueint;
}

int send_message(string msg, SOCKET socket) {
    int return_value = send(socket, msg.c_str(), msg.length(), 0);
    if (return_value == SOCKET_ERROR) {
        cerr << "Send failed: " << WSAGetLastError() << endl;
    } else {
        cout << "Message sent to the server: " << msg << endl;
    }
    return return_value;
}

void binary_exponential_backoff(SOCKET clientSocket, string input, int k) {
    int attempt = 0;
    while (attempt < k) {
        int rand_max = (1 << attempt) - 1;  // 2^k - 1
        int randomNum = rand() % (rand_max + 1);

        int wait_time = randomNum * 1000;  
        Sleep(wait_time);

        send_message(input, clientSocket);
        char buffer[1024];
        int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        if (recvSize > 0) {
            buffer[recvSize] = '\0';
            cout << "Server response: " << buffer << endl;

            if (string(buffer) == "HUH!") {
                cout << "Collision detected, retrying..." << endl;
                attempt++;
            } else {
                cout << "Success, server accepted!" << endl;
                break;
            }
        } else {
            cerr << "Recv failed: " << WSAGetLastError() << endl;
            break;
        }
    }
    if (attempt == k) {
        cout << "Max attempts reached, giving up." << endl;
    }
}

int main() {
    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    const char* configfilename = "config.json";

    char* jsondata = read_file(configfilename);
    cJSON* configjson = cJSON_Parse(jsondata);

    char* server_ip = get_server_ip(configjson);
    int server_port = get_server_port(configjson);
    int k = get_k(configjson);

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock" << endl;
        return 1;
    }

    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSocket == INVALID_SOCKET) {
        cerr << "Socket creation failed: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr(server_ip);
    serverAddr.sin_port = htons(server_port);

    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        cerr << "Connection failed: " << WSAGetLastError() << endl;
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    cout << "Connected to the server" << endl;

    string input;
    cout << "Enter the message to be sent: ";
    cin >> input;
    input.push_back('\n');

    srand(time(0));

    binary_exponential_backoff(clientSocket, input, k);

    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
