#include <iostream>
#include <winsock2.h>
#include <pthread.h>
#include "cJSON.h"
#include <cstdlib>
#include <ctime>
#include <set>

#pragma comment(lib, "ws2_32.lib")
#define BUFFER_SIZE 1024

using namespace std;

struct client_data {
    SOCKET clientSocket;
    set<string> receivedMessages;  
};

char* read_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* content = (char*)malloc(length + 1);
    fread(content, 1, length, file);
    content[length] = '\0';

    fclose(file);
    return content;
}

int get_server_port(cJSON* config_json) {
    cJSON* server_port = cJSON_GetObjectItemCaseSensitive(config_json, "server port");
    return server_port->valueint;
}

void* handle_client(void* client_info) {
    client_data* data = (client_data*)client_info;
    SOCKET clientSocket = data->clientSocket;
    char buffer[BUFFER_SIZE];

    while (true) {
        int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
        if (recvSize > 0) {
            buffer[recvSize] = '\0';
            cout << "Received message from client: " << buffer << endl;

            string message(buffer);
            if (data->receivedMessages.find(message) != data->receivedMessages.end()) {
                string response = "HUH!\n";
                send(clientSocket, response.c_str(), response.length(), 0);
                cout << "Collision detected, sent HUH! to client" << endl;
            } else {
                data->receivedMessages.insert(message);
                string response = "Success\n";
                send(clientSocket, response.c_str(), response.length(), 0);
                cout << "Accepted message, sent Success to client" << endl;
            }
        } else if (recvSize == 0) {
            cout << "Client disconnected" << endl;
            break;
        } else {
            cerr << "Recv failed: " << WSAGetLastError() << endl;
            break;
        }
    }

    closesocket(clientSocket);
    delete data;
    return NULL;
}

int main() {
    WSADATA wsaData;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrSize = sizeof(clientAddr);

    const char* configfilename = "config.json";
    char* jsondata = read_file(configfilename);
    cJSON* configjson = cJSON_Parse(jsondata);
    int server_port = get_server_port(configjson);

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock: " << WSAGetLastError() << endl;
        return 1;
    }

    serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (serverSocket == INVALID_SOCKET) {
        cerr << "Socket creation failed: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(server_port);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        cerr << "Bind failed: " << WSAGetLastError() << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    if (listen(serverSocket, 5) == SOCKET_ERROR) {
        cerr << "Listen failed: " << WSAGetLastError() << endl;
        closesocket(serverSocket);
        WSACleanup();
        return 1;
    }

    cout << "Server is listening on port " << server_port << endl;

    while (true) {
        clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);
        if (clientSocket == INVALID_SOCKET) {
            cerr << "Accept failed: " << WSAGetLastError() << endl;
            continue;  
        }

        client_data* data = new client_data;
        data->clientSocket = clientSocket;

        pthread_t client_thread;
        pthread_create(&client_thread, NULL, handle_client, (void*)data);
        pthread_detach(client_thread);
    }

    closesocket(serverSocket);
    WSACleanup();

    return 0;
}
