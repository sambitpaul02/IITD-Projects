import matplotlib.pyplot as plt

clients = [1, 4, 8]
aloha = [0.08, 0.12, 0.12]
beb = [0.09, 0.13, 0.11]
sensing = [0.09, 0.08, 0.17]

plt.plot(clients, aloha, marker='o', label='Aloha')
plt.plot(clients, beb, marker='o', label='BEB')
plt.plot(clients, sensing, marker='o', label='Sensing')
plt.xlabel('Concurrent Clients')
plt.ylabel('Completion Time')
plt.title('Aloha, BEB, and Sensing Protocols')
plt.legend()
#plt.savefig('plot3.png')
plt.show()
