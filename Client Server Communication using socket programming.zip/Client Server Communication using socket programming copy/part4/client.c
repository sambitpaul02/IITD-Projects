#include <iostream>
#include <winsock2.h>
#include <string>
#include <map>
#include <vector>
#include <sstream>
#include <chrono>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

int send_the_string(string msg, SOCKET socket) {
    int return_value = send(socket, msg.c_str(), msg.length(), 0);
    if (return_value == SOCKET_ERROR) {
        cerr << "Send failed: " << WSAGetLastError() << endl;
    } else {
        cout << "Message sent to the server: " << msg << endl;
    }
    return return_value;
}

int main() {

    // TODO: \n seperated ==> COMMA Seprated Words

    WSADATA wsaData;
    SOCKET clientSocket;
    struct sockaddr_in serverAddr;
    int return_value;

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock" << endl;
        return 1;
    }

    // Create a socket
    clientSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSocket == INVALID_SOCKET) {
        cerr << "Socket creation failed: " << WSAGetLastError() << endl;
        WSACleanup();
        return 1;
    }

    // Set up the server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Assuming server runs on localhost
    serverAddr.sin_port = htons(8888);  // Port used by the server

    // Connect to the server
    return_value = connect(clientSocket, (struct sockaddr*) &serverAddr, sizeof(serverAddr));
    if (return_value == SOCKET_ERROR) {
        cerr << "Connection failed: " << WSAGetLastError() << endl;
        closesocket(clientSocket);
        WSACleanup();
        return 1;
    }

    cout << "Connected to the server" << endl;

    string input;
    cout << "Enter the offset to be sent: ";
    cin >> input;
    input.push_back('\n');  // Append '\n' to the input as per the protocol

    send_the_string(input, clientSocket);

    vector<string> client_words;  // To store received words
    char buffer[1024];  // Buffer to hold incoming data
    auto start = std::chrono::high_resolution_clock::now();

    // Receive packets from the server
    while (1) {
        int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);

        if (recvSize > 0) {

            buffer[recvSize] = '\0';  // Null-terminate the received data

            string received_data(buffer);
            stringstream ss(received_data);
            string word;

            while (getline(ss, word, '\n')) {
                if (word == "$$" || word == "EOF") {
                    break;  // Stop when $$ or EOF is encountered
                }
                client_words.push_back(word);  // Add word to client_words
            }

            if (word == "$$" || word == "EOF") {
                break;  // Break the outer loop if special word is encountered
            }
        } else if (recvSize == 0) {
            cout << "Server closed the connection" << endl;
            break;
        } else {
            cerr << "Recv failed: " << WSAGetLastError() << endl;
            break;
        }
    }


    // Map to store the frequency of each word
    map<string, int> word_frequency;

    // Count the frequency of each word
    for (const string &word : client_words) {
        word_frequency[word]++;
    }

    // Display the frequency of each word
    for (const auto &entry : word_frequency) {
        cout << entry.first << ", " << entry.second << endl;
    }





    auto end = std::chrono::high_resolution_clock::now();


    std::chrono::duration<double> elapsed = end - start;

    std::cout << "Time taken to execute the program: " << elapsed.count() << " seconds" << std::endl;

    string ext;
    cin >> ext;

    return 0;


    // Clean up
    closesocket(clientSocket);
    WSACleanup();

    return 0;
}
