#include <iostream>
#include <winsock2.h>
#include <iostream>
#include <winsock2.h>
#include <string>
#include <map>
#include <vector>
#include <sstream>
#include <fstream>
#include "cJSON.h"

//g++ -o server_test.exe server_test.c cJSON.c -L/lib -lpthreadVC2 -I/include -I. -L. -lws2_32

#define BUFFER_SIZE 1024
char buffer[1024];

struct client_data {
    SOCKET clientSocket;
    int k;
    int p;
    char* filename;
};

#pragma comment(lib, "ws2_32.lib")

using namespace std;

char* read_file(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file %s\n", filename);
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char* content = (char*)malloc(length + 1);
    fread(content, 1, length, file);
    content[length] = '\0';

    fclose(file);
    return content;
}
char* get_server_ip(cJSON* config_json) {
    cJSON* server_ip = cJSON_GetObjectItemCaseSensitive(config_json, "server ip");
    // if (cJSON_IsString(server_ip)) {}
    return server_ip->valuestring;
}
char* get_filename(cJSON* config_json) {
    cJSON* fname = cJSON_GetObjectItemCaseSensitive(config_json, "filename");
    // if (cJSON_IsString(server_ip)) {}
    return fname->valuestring;
}
int get_server_port(cJSON* config_json) {
    cJSON* server_port = cJSON_GetObjectItemCaseSensitive(config_json, "server port");
    //if (cJSON_IsNumber(server_port)) {}
    return server_port->valueint;
}
int get_k(cJSON* config_json) {
    cJSON* k_value = cJSON_GetObjectItemCaseSensitive(config_json, "k");
    return k_value->valueint;

    //if (cJSON_IsNumber(k_value)) {}
}
int get_p(cJSON* config_json) {
    cJSON* p_value = cJSON_GetObjectItemCaseSensitive(config_json, "p");
    return p_value->valueint;


    //if (cJSON_IsNumber(p_value)) {}

}
int get_n(cJSON* config_json) {
    cJSON* n_value = cJSON_GetObjectItemCaseSensitive(config_json, "n");
    return n_value->valueint;
}


vector<string> getWordsFromFile(ifstream &file, int offset, int k) {
    file.clear();
    file.seekg(0, ios::beg);
    string line, word;
    vector<string> words;
    int no_of_words = 0;  // Total number of words (comma-separated)

    // First, read the whole line (comma-separated values) and split into words
    getline(file, line);
    stringstream ss(line);

    // Split the line by commas and store words
    while (getline(ss, word, ',')) {
        words.push_back(word);
        no_of_words++;
    }

    // If offset is greater than the number of words, return empty vector
    if (offset >= no_of_words) {
        return {};
    }

    // Get k words starting from the offset
    vector<string> result;
    for (int i = offset; i < no_of_words && result.size() < k; ++i) {
        result.push_back(words[i]);
    }

    return result;
}



int receive_data_as_string( SOCKET clientSocket){

  int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
  if (recvSize > 0) {
      buffer[recvSize] = '\0';
      cout << "Received message: " <<buffer  << endl;
  } else if (recvSize == 0) {
      cout << "Client disconnected" << endl;
  } else {
      cerr << "Recv failed: " << WSAGetLastError() << endl;
  }

  return 0;
}
int receive_data( SOCKET clientSocket, char ending_char){

  int recvSize = recv(clientSocket, buffer, sizeof(buffer) - 1, 0);
  if (recvSize > 0) {
      buffer[recvSize] = '\0';
      for (int i = 0; i < recvSize; ++i) {
            if (buffer[i] == ending_char) {
                buffer[i] = '\0';
                break;
            }
        }
      cout << "Received message: " <<buffer  << endl;
  }
  return 0;
}

void show_packet_cout(string x, int number){
  cout<<"-------------Packet "<<number<<"-------------\n"<<x<<endl<<"-----------------------------------"<<endl;
}
void show_packet_cout(string x){
  cout<<"-------------Packet-------------\n"<<x<<endl<<"--------------------------------"<<endl;
}




int round_robin_serve(vector<SOCKET>& clients, vector<int>& clients_offset_vector, int k, int p, char* filename_from_config) {
    bool all_clients_done = false;
    vector<bool> client_done(clients.size(), false);

    while (!all_clients_done) {
        all_clients_done = true;
        Sleep(500);
        for (size_t i = 0; i < clients.size(); ++i) {
            if (!client_done[i]) {
                SOCKET clientSocket = clients[i];
                int offset = clients_offset_vector[i];

                ifstream file(filename_from_config);  // Declare a named ifstream object
                vector<string> words = getWordsFromFile(file, offset, k);  // Pass the lvalue to the function

                if (!words.empty()) {
                    words.push_back("EOF\n");
                } else {
                    words.push_back("EOF\n");
                    client_done[i] = true;  // Mark client as done if all words are sent
                }

                vector<string> packet;
                for (size_t j = 0; j < p && !words.empty(); ++j) {
                    packet.push_back(words[j]);
                }

                string packet_str = "";
                for (const string& word : packet) {
                    packet_str += word + "\n";
                }

                show_packet_cout(packet_str.c_str());
                int sendResult = send(clientSocket, packet_str.c_str(), packet_str.length(), 0);
                Sleep(500);

                clients_offset_vector[i] += p;
                if (!client_done[i]) all_clients_done = false;
            }
        }
    }
    return 0;
}

// int main() {
//     // Your existing setup code remains unchanged...
//
//     cout << "All clients connected, performing Round Robin logic..." << endl;
//
//     // Perform Round Robin serving
//     round_robin_serve(clients, clients_offset_vector, k, p, filename_from_config);
//
//     // Close all client sockets after serving
//     for (SOCKET clientSocket : clients) {
//         closesocket(clientSocket);
//     }
//
//     closesocket(serverSocket);
//     WSACleanup();
//
//     return 0;
// }
//


int main() {
    WSADATA wsaData;
    SOCKET serverSocket, clientSocket;
    struct sockaddr_in serverAddr, clientAddr;
    int clientAddrSize = sizeof(clientAddr);
    int bytesReceived;

    const char* configfilename = "config.json";

    char* jsondata = read_file(configfilename);
    cJSON* configjson = cJSON_Parse(jsondata);

    char* server_ip = get_server_ip(configjson);
    int server_port = get_server_port(configjson);
    int k = get_k(configjson);
    int p = get_p(configjson);
    int n = get_n(configjson);
    char* filename_from_config = get_filename(configjson);

    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        cerr << "Failed to initialize Winsock: " << WSAGetLastError() << endl;
        return 1;
    }

    serverSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    cout << "Socket created successfully" << endl;

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(server_port);

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == SOCKET_ERROR) {
        cerr << "Bind failed: " << WSAGetLastError() << endl;
        return 1;
    }

    int listen_return_value = listen(serverSocket, 1);
    cout << "Listening..." << endl;

    vector<SOCKET> clients;
    clients.reserve(n); // Reserve space for n clients
    vector<int> clients_offset_vector;
    clients_offset_vector.reserve(n); // Reserve space for n clients offset data

    cout << "Waiting for " << n << " clients to connect..." << endl;

    while (clients.size() < n) {
        SOCKET clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);
        if (clientSocket == INVALID_SOCKET) {
            cerr << "Accept failed: " << WSAGetLastError() << endl;
            continue;
        }
        cout << "Client connected. Adding to the client list." << endl;
        clients.push_back(clientSocket);  // Add client to the vector
    }

    cout << "All clients connected, performing logic..." << endl;


    for (SOCKET clientSocket : clients) {
        char recvBuffer[BUFFER_SIZE];
        int recvResult = recv(clientSocket, recvBuffer, BUFFER_SIZE, 0);
        if (recvResult > 0) {
            int offset = atoi(recvBuffer);  // Convert received buffer to an integer
            clients_offset_vector.push_back(offset);  // Store the offset in the vector
            cout << "Received offset: " << offset << " from client." << endl;
        }
    }
    round_robin_serve(clients, clients_offset_vector, k, p, filename_from_config);



    // Close all client sockets
    for (SOCKET clientSocket : clients) {
        closesocket(clientSocket);
    }

    closesocket(serverSocket);
    WSACleanup();

    string ext;
    cin>>ext;


    return 0;
}
