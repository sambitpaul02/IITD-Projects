import matplotlib.pyplot as plt

concurrentclients = [1, 4, 8]
fifotime = [0.11, 0.12, 0.17]
rrtime = [0.08, 0.13, 0.16]

plt.plot(concurrentclients, fifotime, marker='o', label='FIFO')
plt.plot(concurrentclients, rrtime, marker='o', label='RR')
plt.xlabel('Concurrent Clients')
plt.ylabel('Avg Completion Time')
plt.title('FIFO vs. RR')
plt.legend()
plt.grid(True)
#plt.savefig('plot4.png')
plt.show()

