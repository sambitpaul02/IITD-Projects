package NewCoinPackage;

import NewCoinPackage.TransactionBlock;
import NewCoinPackage.Members;

public class Transaction {

  public String coinID;
  public Members Source;
  public Members Destination;
  public TransactionBlock coinsrc_block;
  public Transaction(String coin , Members src , Members dst , TransactionBlock coinsrc_block){
    this.coinID = coin;
    this.Source = src;
    this.Destination = dst;
    this.coinsrc_block = coinsrc_block;
  }

}
