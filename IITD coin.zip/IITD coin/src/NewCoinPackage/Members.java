package NewCoinPackage;

import java.util.*;

import HelperClasses.CRF;
import HelperClasses.MerkleTree;
import HelperClasses.Pair;
import NewCoinPackage.Transaction;
import NewCoinPackage.TransactionBlock;
import NewCoinPackage.NewCoin_Honest;
import NewCoinPackage.NewCoin_Malicious;
import NewCoinPackage.MissingTransactionException;

public class Members
 {

  public String UID;
  public List<Pair<String, TransactionBlock>> mycoins = new ArrayList<>();; //coin id , source block
  public ArrayList<Transaction> in_process_trans = new ArrayList<>();
  public ArrayList<Pair<Transaction,TransactionBlock>> finalised_transaction = new ArrayList<>();
  public ArrayList<proof_of_transaction> pending_proofs = new ArrayList<>();

  public void initiateCoinsend(Members dest) {

   if(mycoins.size()!=0){
    String coin_id = mycoins.get(0).get_first();
    TransactionBlock src_blk = mycoins.get(0).get_second();
    mycoins.remove(0); // removed from members wallet ( mycoins )
    Transaction t = new Transaction(coin_id,this,dest,src_blk);

    Global_Data.tx_queue.add(t); // add the transaction to the global mempool
    this.in_process_trans.add(t); // add the transaction in local mempool
   }
   else {
    System.out.println("You don't have a coin");
   }
  }

//
//  public void initiateCoinsend(String destUID, NewCoin_Malicious Newobj) {
//
//  }

  public Pair<List<Pair<String, String>>, List<Pair<String, String>>> finalizeCoinsend (Transaction tobj, NewCoin_Honest NewObj) throws MissingTransactionException {
   return null;
  }

  public void filterTransaction (ArrayList<Transaction> t) {

   for(Transaction trc : t)
   {
    int valid=0;
    // Check source is valid
    TransactionBlock src_block = trc.coinsrc_block;
    for(Transaction t_src : src_block.trarray){
     if(( trc.coinID == t_src.coinID ) && ( trc.Source == t_src.Destination )){
      valid = 1;
      break;
     }
    }
    if(valid==0){
     // Source of the transaction is invalid
     Global_Data.invalid_tx_queue.add(trc);
     Global_Data.tx_queue.remove(trc);
     continue;
    }
    // check all blocks in blockchain after that block and find if any double spending or not

    int source_index = Global_Data.block_chain.indexOf(src_block);
    for(int i = source_index; i < Global_Data.block_chain.size();i++)
    {
     TransactionBlock curr_block = Global_Data.block_chain.get(i);
     for(Transaction t_src : curr_block.trarray){
      if((trc.coinID == t_src.coinID) && (trc.Source == t_src.Source)){

        // attempt to double spending that is why invalid transaction
       valid = 0;
       Global_Data.invalid_tx_queue.add(trc);
       Global_Data.tx_queue.remove(trc);
       break;

      }
     }
     if(valid==0){
      break;
     }
     // transaction is proved valid upto this block
    }

   }
  }

  public void MineCoin() {
   //filtering the invalid transactions from the valid Queue
   filterTransaction(Global_Data.tx_queue);


   int tr_count = Global_Data.tr_count;
   if(Global_Data.tx_queue.size()>=tr_count-1) // mine iff more than tr_count no. of trc are available in the mempool
   {

     Transaction[] tr_arr = new Transaction[tr_count];
     for(int i =0;i<tr_count-1;i++)
     {
      tr_arr[i] = Global_Data.tx_queue.get(0);
      Global_Data.tx_queue.remove(0); // remove the first transaction from the global mempool each time
     }

     //Miner's coin creation
     String coin_id = String.format("%06d", Global_Data.last_coin_id);
     Global_Data.last_coin_id++;

     Transaction my_trc = new Transaction(coin_id,null,this,null);
     tr_arr[tr_count-1] = my_trc;

     TransactionBlock last_block = Global_Data.block_chain.get(Global_Data.block_chain.size()-1);
     TransactionBlock new_block = new TransactionBlock(tr_arr,last_block);

     Global_Data.block_chain.add(new_block);
     Global_Data.last_block_dgst = new_block.dgst;
//     Global_Data.add_block_to_Tree(new_block);
     for(Transaction t : new_block.trarray)
     {

       // Send the coins to the destination member's wallet
//       if(t.Source!=null)
//       {
         Members s = t.Source;
         Members d = t.Destination;
         String coin = t.coinID;

         Pair<Transaction,TransactionBlock> p1 = new Pair<>(t,new_block);
         if(t.Source!=null) {
           s.finalised_transaction.add(p1);
           s.in_process_trans.remove(t);
         }

         Pair<String,TransactionBlock> p2 = new Pair<>(coin,new_block);
         d.mycoins.add(p2);
//       }
     }

   }
  }  

  public void MineCoinMalicious(int blockIndex) {
   int tr_count = Global_Data.tr_count;
   filterTransaction(Global_Data.tx_queue);


   if(Global_Data.tx_queue.size()>=tr_count)
   {

    Transaction[] tr_arr = new Transaction[tr_count];
    for(int i =0;i<tr_count-1;i++)
    {
     tr_arr[i] = Global_Data.tx_queue.get(i);
    }

    //Miner's coin creation
    String coin_id = String.format("%06d", Global_Data.last_coin_id);
    Global_Data.last_coin_id++;

    Transaction my_trc = new Transaction(coin_id,null,this,null);
    tr_arr[tr_count-1] = my_trc;


    TransactionBlock block = Global_Data.block_chain.get(blockIndex);
    TransactionBlock new_block = new TransactionBlock(tr_arr,block);



    Global_Data.add_block_to_Tree(new_block);


   }
  }


  public void SendProof(Pair<Transaction,TransactionBlock> p){

   // Sender will send the proof of trc to the receiver and that will be stored in receiver's pending proofs pool

   Transaction t = p.get_first();
   TransactionBlock tb = p.get_second();
   Members dst = t.Destination;
   proof_of_transaction obj = new proof_of_transaction(t,tb);
   dst.pending_proofs.add(obj);

  }

  public Boolean VerifyProof(proof_of_transaction proof){

   // Member can verify the proofs from it's own pending proofs pool only
   if(proof.trc.Destination!=this){
    System.out.println("Destination of the transaction is incorrect ");
    return false ;
   }
   if(!check_sc_path(proof.trc,proof.sc_path).equals(proof.trc_blk.trsummary)){
    return false ;
   }
   CRF obj = new CRF(64);
   if(proof.blockH!=null){

     for(BlockHeader b : proof.blockH){
      String b_hash = b.hash;
      if(!b_hash.startsWith("0000")){
       return false;
      }
      String prev_blk_hash = b.prev_block_hash;
      String bh = obj.Fn(prev_blk_hash + "#" + b.trc_summary + "#" + b.nonce );
      if(bh!=b_hash){
       return false;
      }

     }

   }
   this.pending_proofs.remove(proof);
   System.out.println("Verified : Member "+proof.trc.Source.UID+" has send Coin "+proof.trc.coinID+" to Member "+proof.trc.Destination.UID);
   return true;
  }

  public String check_sc_path(Transaction t ,ArrayList<Pair<String ,String>> sc_path){
   CRF obj = new CRF(64);
   MerkleTree m = new MerkleTree();
   String final_val = m.get_str(t);

   for(Pair<String,String> p : sc_path){

    String val = p.get_first(); // sibling value
    String rightorleft = p.get_second(); // location
    if(rightorleft=="l"){
     final_val = obj.Fn(val + "#" + final_val);
    }
    else if(rightorleft=="r"){
     final_val = obj.Fn(final_val + "#" + val);
    }
   }
   return final_val;
  }

//  public boolean CheckTransaction(Transaction[] t) {
//   for (Transaction trc : t) {
//    int valid = 0;
//    // Check source is valid
//    TransactionBlock src_block = trc.coinsrc_block;
//    for (Transaction t_src : src_block.trarray) {
//     if ((trc.coinID == t_src.coinID) && (trc.Source == t_src.Destination)) {
//      valid = 1;
//      break;
//     }
//    }
//    if (valid == 0) {
//     return false;
//    }
//    // check all blocks in blockchain after that block and find if any double spending or not
//
//    int source_index = Global_Data.block_chain.indexOf(src_block);
//    for (int i = source_index; i < Global_Data.block_chain.size(); i++) {
//     TransactionBlock curr_block = Global_Data.block_chain.get(i);
//     for (Transaction t_src : curr_block.trarray) {
//      if ((trc.coinID == t_src.coinID) && (trc.Source == t_src.Source)) {
//       valid = 0;
//       return false;
//      }
//     }
//     if (valid == 0) {
//      return false;
//     }
//     // transaction is proved valid upto this block
//    }
//    if(valid ==0){
//     return false;
//    }
//   }
//   return true;
//  }
//
//  public Boolean VerifyBlock(TransactionBlock blk){
//
//   Transaction[] tr = blk.trarray;
//   if(!CheckTransaction(tr)){
//    return false;
//   }
//
//   if(!blk.dgst.startsWith("0000")){
//    return false;
//   }
//   String ip = blk.previous.dgst + "#" + blk.trsummary + "#" + blk.nonce;
//   CRF obj = new CRF(64);
//   String op_dgst = obj.Fn(ip);
//
//   if(!blk.dgst.equals(op_dgst)){
//    return false;
//   }
//
//   MerkleTree mt = new MerkleTree();
//   String root = mt.Build(tr);
//
//   if(!root.equals(blk.trsummary)){
//    return false;
//   }
//   return true;
//  }


}

