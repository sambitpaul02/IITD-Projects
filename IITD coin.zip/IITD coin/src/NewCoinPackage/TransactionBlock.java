package NewCoinPackage;

import HelperClasses.CRF;
import NewCoinPackage.Transaction;
import HelperClasses.MerkleTree;
import java.security.SecureRandom;
import java.util.ArrayList;

public class TransactionBlock {

  public Transaction[] trarray;
  public TransactionBlock previous;

//  public MerkleTree Tree;
  public String trsummary;
  public String nonce;
  public String dgst;



  private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  private static final int NONCE_LENGTH = 10;

  // SecureRandom ensures a strong random number generation
  private static final SecureRandom random = new SecureRandom();

  // Method to generate a random 10-character nonce
  public static String generateNonce() {
    StringBuilder nonce = new StringBuilder(NONCE_LENGTH);

    // Append random characters to the nonce string
    for (int i = 0; i < NONCE_LENGTH; i++) {

      int index = random.nextInt(CHARACTERS.length());
      nonce.append(CHARACTERS.charAt(index));

    }

    return nonce.toString();
  }

  public TransactionBlock(Transaction[] t,TransactionBlock prev_block) {
    this.trarray = t;
    this.previous = prev_block;

    MerkleTree tree = new MerkleTree();
    String summary = tree.Build(t);
    this.trsummary = summary;

    String nonce = generateNonce();

    String input = Global_Data.last_block_dgst + "#" + summary + "#" + nonce ;

    CRF crf = new CRF(64);
    while(!crf.Fn(input).substring(0,4).equals("0000")){
      nonce = generateNonce();
      input = Global_Data.last_block_dgst + "#" + summary + "#" + nonce;
    }
    this.nonce = nonce;
    this.dgst = crf.Fn(input);


  }

}
