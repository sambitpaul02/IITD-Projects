package NewCoinPackage;

import HelperClasses.CRF;
import HelperClasses.MerkleTree;

import java.util.ArrayList;
import java.util.TreeMap;

public class Global_Data {

    public static ArrayList<Members> members_list = new ArrayList<>();
    public static ArrayList<Transaction> tx_queue = new ArrayList<>();
    public static ArrayList<Transaction> invalid_tx_queue = new ArrayList<>();
    public static ArrayList<TransactionBlock> block_chain = new ArrayList<>();

    public static TreeMap<String, ArrayList<TransactionBlock>> blockchain_tree_visualization = new TreeMap<>();

    public static String last_block_dgst = "null";
    public static int last_coin_id = 000000;

    public static int last_member_id = 000;

    public static int tr_count = 8;

    public static void add_block_to_Tree(TransactionBlock transactionBlock){
        String block_parent = transactionBlock.previous.dgst;

        if (block_parent == null){
            block_parent = "null";
        }

        if (!blockchain_tree_visualization.containsKey(block_parent)){
            ArrayList<TransactionBlock> arrayList = new ArrayList<TransactionBlock>();
            arrayList.add(transactionBlock);
            blockchain_tree_visualization.put(block_parent, arrayList);
            block_chain.add(transactionBlock);
        }else{
            ArrayList<TransactionBlock> arrayList = blockchain_tree_visualization.get(block_parent);
            arrayList.add(transactionBlock);
            blockchain_tree_visualization.put(block_parent, arrayList);
        }



        refresh_valid_longest_chain(transactionBlock);

    }




    private static boolean is_valid_block(TransactionBlock transactionBlock){
        return VerifyBlock(transactionBlock);
    }
    public static boolean CheckTransaction(Transaction[] t) {
        for (Transaction trc : t) {
            int valid = 0;
            // Check source is valid
            TransactionBlock src_block = trc.coinsrc_block;
            if (src_block != null) {
                for (Transaction t_src : src_block.trarray) {
                    if ((trc.coinID == t_src.coinID) && (trc.Source == t_src.Destination)) {
                        valid = 1;
                        break;
                    }
                }
                if (valid == 0) {
                    return false;
                }
                // check all blocks in blockchain after that block and find if any double spending or not

                int source_index = Global_Data.block_chain.indexOf(src_block);
                for (int i = source_index; i < Global_Data.block_chain.size(); i++) {
                    TransactionBlock curr_block = Global_Data.block_chain.get(i);
                    for (Transaction t_src : curr_block.trarray) {
                        if ((trc.coinID == t_src.coinID) && (trc.Source == t_src.Source)) {
                            valid = 0;
                            return false;
                        }
                    }
                    if (valid == 0) {
                        return false;
                    }
                    // transaction is proved valid upto this block
                }
                if (valid == 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public static Boolean VerifyBlock(TransactionBlock blk){

        // Check transactions are valid or not
        Transaction[] tr = blk.trarray;
        if(!CheckTransaction(tr)){
            return false;
        }

        // Check block digest is valid or not
        if(!blk.dgst.startsWith("0000")){
            return false;
        }
        String ip = blk.previous.dgst + "#" + blk.trsummary + "#" + blk.nonce;
        CRF obj = new CRF(64);
        String op_dgst = obj.Fn(ip);

        if(!blk.dgst.equals(op_dgst)){
            return false;
        }

        // Check the tr_summary is valid or not
        MerkleTree mt = new MerkleTree();
        String root = mt.Build(tr);

        if(!root.equals(blk.trsummary)){
            return false;
        }
        return true;
    }








    //to sambit: Ignore functions below this line. They are helper functions
    private static TransactionBlock findBlockByHash(String blockHash) {
        for (ArrayList<TransactionBlock> blocks : blockchain_tree_visualization.values()) {
            for (TransactionBlock block : blocks) {
                if (block.dgst.equals(blockHash)) {
                    return block; // Return the block if found
                }
            }
        }
        return null; // Return null if not found
    }
    private static String dfs(TransactionBlock block, int depth, DepthResult result) {
        // Check if the current block is valid
        if (!is_valid_block(block)) {
            return null; // Return null for invalid blocks
        }

        // If the block has no children, return its hash
        if (!blockchain_tree_visualization.containsKey(block.dgst)) {
            return block.dgst; // Return the current block's hash if it has no children
        }

        // Increment the current depth
        depth++;
        String longestHash = block.dgst; // Initialize with the current block's hash
        int longestDepth = depth; // Initialize with the current depth

        for (TransactionBlock child : blockchain_tree_visualization.get(block.dgst)) {
            String childLongestHash = dfs(child, depth, result);
            if (childLongestHash != null) { // Only consider valid child hashes
                int childDepth = result.depth; // Get the depth of the valid child path

                // Update longest hash and depth if needed
                if (childDepth > longestDepth) {
                    longestDepth = childDepth;
                    longestHash = childLongestHash; // Update longest hash
                }
            }
        }

        // Update the result with the longest depth found
        result.depth = longestDepth;
        return longestHash; // Return the longest hash found
    }
    private static class DepthResult {
        int depth = 0; // Initialize depth
    }
    private static void refresh_valid_longest_chain(TransactionBlock transactionBlock) {
        if (is_valid_block(transactionBlock) && transactionBlock.previous.dgst != last_block_dgst) {

            String last_block_dgst_2 = dfs(transactionBlock, 0, new DepthResult());
            last_block_dgst = last_block_dgst_2;
            block_chain = get_path_from_genesis_to_hash(last_block_dgst_2);

        }else{
            block_chain.add(transactionBlock);
            last_block_dgst = transactionBlock.dgst;
        }
    }
    public static ArrayList<TransactionBlock> get_path_from_genesis_to_hash(String blockHash) {
        ArrayList<TransactionBlock> path = new ArrayList<>();

        // Check if the block exists in the blockchain visualization
        if (!blockchain_tree_visualization.containsKey(blockHash)) {
            return path; // Return empty if the block doesn't exist
        }

        // Start from the block with the given hash
        TransactionBlock currentBlock = findBlockByHash(blockHash);

        while (currentBlock != null) {
            path.add(0, currentBlock); // Add to the front to maintain the order from genesis to the target block

            // Move to the previous block (parent block)
            if (currentBlock.previous != null) {
                currentBlock = findBlockByHash(currentBlock.previous.dgst);
            } else {
                break; // No previous block (reached genesis)
            }
        }

        return path;
    }
    public static void print_tree() {
        System.out.println("Blockchain Tree:");
//        System.out.println(blockchain_tree_visualization.get("null").get(0));
        print_tree_helper("null", 0);
    }

    // Helper method to print the tree recursively
    private static void print_tree_helper(String parentHash, int depth) {
        ArrayList<TransactionBlock> blocks = blockchain_tree_visualization.get(parentHash);

        if (blocks != null) {
            for (TransactionBlock block : blocks) {
                // Print the block's hash with indentation
                System.out.println("  ".repeat(depth) + block.dgst);

                // Recursively print child blocks
                print_tree_helper(block.dgst, depth + 1);
            }
        }
    }

}
