package NewCoinPackage;

import NewCoinPackage.Transaction;
import NewCoinPackage.EmptyQueueException;

import java.util.ArrayList;

public class TransactionQueue {

//  public Transaction firstTransaction;
//  public Transaction lastTransaction;
  public int numTransactions;

  ArrayList<Transaction> queue = new ArrayList<>();
  public void AddTransactions (Transaction transaction) {
    queue.add(transaction);
  }
  
  public Transaction RemoveTransaction () throws EmptyQueueException {
    Transaction t = queue.get(0);
    queue.remove(0);
    return t;
  }

  public int size() {
    int size = queue.size();
    return size;
  }
}
