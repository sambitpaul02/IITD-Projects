package NewCoinPackage;

public class BlockHeader {
    String hash;
    String nonce;
    String trc_summary;
    String prev_block_hash;

    public BlockHeader(String hash,String nonce , String trc_summary , String prev_block_hash){
        this.hash = hash;
        this.nonce = nonce;
        this.trc_summary = trc_summary;
        this.prev_block_hash = prev_block_hash;
    }
}
