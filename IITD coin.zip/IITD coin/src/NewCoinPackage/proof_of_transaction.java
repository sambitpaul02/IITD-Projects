package NewCoinPackage;

import HelperClasses.MerkleTree;
import HelperClasses.Pair;

import java.net.ProtocolFamily;
import java.util.ArrayList;
import java.util.List;

public class proof_of_transaction {
    Transaction trc;
    TransactionBlock trc_blk;
    ArrayList<Pair<String ,String>> sc_path ;
    String prev_block_hash;
    ArrayList<BlockHeader> blockH = null ;

    public proof_of_transaction(Transaction t,TransactionBlock t_blk ){
        this.trc = t;
        this.trc_blk = t_blk;
        this.prev_block_hash = t_blk.previous.dgst;
        MerkleTree mt = new MerkleTree();
        sc_path = mt.Sibling_coupled_path(t_blk,t); // correct

        int index = Global_Data.block_chain.indexOf(t_blk);
        // add all the block header of the blocks after the t_blk.
        if(index != Global_Data.block_chain.size()-1){
            for(int i=index+1 ; i<Global_Data.block_chain.size()-1 ;i++){
                TransactionBlock b = Global_Data.block_chain.get(i);
                BlockHeader obj = new BlockHeader(b.dgst,b.nonce,b.trsummary,b.previous.dgst);
                blockH.add(obj);
            }
        }
    }

}
