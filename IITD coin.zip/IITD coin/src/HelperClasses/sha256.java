package HelperClasses;

import java.nio.charset.StandardCharsets;
import java.security.*;

public class sha256 {

  //StandardCharsets.UTF_8 gives char to Byte encoding using UTF_8 standard
  // get byte returns array of 8 bit binary values , each of them represent a char in the string
  //crypt.digest(Byte[] arr) return the hash of the input byte array as a another byte array

  //String -> Byte array -> Digest(Hash value) -> Hexadecimal of the digest

  protected static String encrypt(String password) {
    String shasum = "";
    try {
      MessageDigest crypt = MessageDigest.getInstance("SHA-256");
      shasum =
        Conversion.byteToHex(  //Static class method ,can be used without creating an object of the class
          crypt.digest(password.getBytes(StandardCharsets.UTF_8))
        );
    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    }
    return shasum;
  }
}
