package HelperClasses;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class Conversion {

    public static String byteToHex(byte[] hash)
    {
        StringBuilder sb = new StringBuilder();
        for (byte b : hash) {
            sb.append(String.format("%02X", b));  //Byte to string conversion using String.format
            //"02" mean hexadecimal should be at least 2 char long "%X" = Hexadecimal
        }
        String result = sb.toString();
        return result;
    }

    public static byte[] hexToByte(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    //Here "encodedKey" is a byte array that represent my public key in X.509 format(A standard encoding format )
    public static PublicKey getPublicKey(byte[] encodedKey) throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        // KeySpec object just wrap ( boxing ) the raw bytes so that Java’s cryptography functions can understand.
        X509EncodedKeySpec k = new X509EncodedKeySpec(encodedKey);

        KeyFactory factory = KeyFactory.getInstance("DSA");
        return factory.generatePublic(k); // this will return public key object by taking any kind of keyspec as input
    }

    //KeySpec is a interface and some concrete class like X509EncodedKeySpec , PKCS8EncodedKeySpec implement keyspec
    //factory.generatePublic( Keyspec ) take keyspec object and return public key object

    // Here "encodedKey" is a byte array that represent my private key in PKCS#8 format
    public static PrivateKey getPrivateKey(byte[] encodedKey) throws NoSuchAlgorithmException, InvalidKeySpecException
    {
        PKCS8EncodedKeySpec k = new PKCS8EncodedKeySpec(encodedKey);

        KeyFactory factory = KeyFactory.getInstance("DSA");
        return factory.generatePrivate(k);

    }
}
