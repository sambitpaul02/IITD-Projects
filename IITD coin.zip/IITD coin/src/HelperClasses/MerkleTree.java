package HelperClasses;

import NewCoinPackage.Transaction;
import HelperClasses.CRF;
import HelperClasses.TreeNode;
import NewCoinPackage.TransactionBlock;
import com.sun.source.tree.Tree;

import java.util.*;

public class MerkleTree {

  // Check the TreeNode.java file for more details
  public TreeNode rootnode;

  void nodeinit(TreeNode node, TreeNode l, TreeNode r, TreeNode p, String val) {
    node.left = l;
    node.right = r;
    node.parent = p;
    node.val = val;
  }

  public String get_str(Transaction tr) {
    String val = tr.coinID;
    if (tr.Source == null) val = val + "#" + "Moderator"; else val =
      val + "#" + tr.Source.UID;

    val = val + "#" + tr.Destination.UID;

    if (tr.coinsrc_block == null) val = val + "#" + "Moderator"; else val =
      val + "#" + tr.coinsrc_block.dgst;

    return val;
  }

  ArrayList<TreeNode> all_nodes = new ArrayList<>(); // All nodes in merkle tree

  public String Build(Transaction[] tr) {
    all_nodes.clear();
    CRF obj = new CRF(64);
    int num_trans = tr.length;
    List<TreeNode> q = new ArrayList<TreeNode>();
    int index=0;

    for (int i = 0; i < num_trans; i++) {
      TreeNode nd = new TreeNode();
      String val = get_str(tr[i]);
      nodeinit(nd, null, null, null, val);
      q.add(nd);
      all_nodes.add(nd);

    }
    TreeNode l, r;
    while (q.size() > 1) {
      l = q.get(0);
      q.remove(0);
      r = q.get(0);
      q.remove(0);
      TreeNode nd = new TreeNode();
      String l_val = l.val;
      String r_val = r.val;
      String data = obj.Fn(l_val + "#" + r_val);
      nodeinit(nd, l, r, null, data);
      l.parent = nd;
      r.parent = nd;
      q.add(nd);


      all_nodes.get(index++).parent = nd;
      all_nodes.get(index++).parent = nd;
      all_nodes.add(nd);

    }
    rootnode = q.get(0);

    return rootnode.val;
  }

  public ArrayList<Pair<String,String>> Sibling_coupled_path(TransactionBlock blk , Transaction t){
    String root = Build(blk.trarray);
    ArrayList<Pair<String,String>> path = new ArrayList<>();

    String v = get_str(t);
    TreeNode trc_node = null;


    for(TreeNode n : all_nodes){
      if(v.equals(n.val)){
        trc_node = n;
        break;
      }
    }

    TreeNode curr_node = trc_node;
    while(curr_node.parent!=null){

      // If current node is in left side of its parent
      if(curr_node.parent.left == curr_node){
        Pair<String,String> p = new Pair<>(curr_node.parent.right.val,"r");
        path.add(p);
        curr_node = curr_node.parent;
      }
      else if(curr_node.parent.right == curr_node){
        Pair<String,String> p = new Pair<>(curr_node.parent.left.val,"l");
        path.add(p);
        curr_node = curr_node.parent;
      }

    }
    return path;

  }
}
