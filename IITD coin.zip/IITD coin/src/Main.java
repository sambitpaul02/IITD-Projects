import HelperClasses.Pair;
import NewCoinPackage.Global_Data;
import NewCoinPackage.Members;
import NewCoinPackage.Transaction;
import NewCoinPackage.TransactionBlock;

import java.util.ArrayList;
public class Main {

    public static void PrintBlockInfo(){
        for(TransactionBlock blk : Global_Data.block_chain){
            System.out.println("Block Hash: "+ blk.dgst);
            System.out.println("Summary: "+ blk.trsummary);
            System.out.println("Nonce :"+ blk.nonce);
            if(blk.previous!=null){
                System.out.println("Previous Block Hash: "+blk.previous.dgst);
            }
            else{
                System.out.println("Previous Block Hash: null");
            }
            System.out.println("-----------------------------------");
        }

    }

    public static void PrintMembersinfo(){
        for(Members m : Global_Data.members_list){

            ArrayList<String> coins = new ArrayList<>();
            for(Pair<String,TransactionBlock> p : m.mycoins){
                coins.add(p.get_first());
            }

            System.out.println("Member id : "+ m.UID);
            System.out.println("Holding coins : "+ coins);
            System.out.println("Balance : "+coins.size()+ " coins ");

            System.out.println("------------------------------------------------------------------------------");

        }
    }

    public static void PrintTransactionQueue(){
        System.out.println("<------------------------------------------------>");
        System.out.println("Pending Transactions are : ");
        if(Global_Data.tx_queue.isEmpty()){
            System.out.println("Empty Transaction Queue");
            System.out.println();
            return;
        }
        for(Transaction t : Global_Data.tx_queue){
            System.out.println("Source "+t.Source.UID+" to "+"Destination " + t.Destination.UID+",coin id: "+ t.coinID);
        }
    }

    public static void Coinsend(Members X,Members Y){
        X.initiateCoinsend(Y);
    }

    public static void ProofSending(){
        for(Members m : Global_Data.members_list){
            for(Pair<Transaction,TransactionBlock> p : m.finalised_transaction){
                m.SendProof(p);
            }
        }
    }




    public static void main(String[] args) {

        // Create the member objects
        for(int i=0;i<5;i++){
            Members mem = new Members();
            int id = Global_Data.last_member_id;
            String mem_id = Integer.toString(id);
            Global_Data.last_member_id++;

            mem.UID = mem_id;
            Global_Data.members_list.add(mem);
        }
        //Moderator is sending each member some coins
        Moderator mod = new Moderator();
        mod.no_of_coins = 3;
        mod.initializeCoin(Global_Data.members_list,8);

        Members A = Global_Data.members_list.get(0); //Member 0
        Members B = Global_Data.members_list.get(1); //Member 1
        Members C = Global_Data.members_list.get(2);
        Members D = Global_Data.members_list.get(3);
        Members E = Global_Data.members_list.get(4);

        // A -> B , B , C
        // B -> A , E , C
        // C -> E , B
        // D -> C

        Coinsend(A,B);
        Coinsend(A,B);
        Coinsend(A,C);
        Coinsend(B,A);
        Coinsend(B,E);
        Coinsend(B,C);
        Coinsend(C,E);
        Coinsend(C,B);
        Coinsend(D,C);

        C.MineCoin();

        Coinsend(A,B);
        Coinsend(B,D);
        Coinsend(B,D);
        Coinsend(E,D);
        Coinsend(E,D);

        B.MineCoin();

        System.out.println();
        System.out.println("__________MEMBERS WALLET_________");
        PrintMembersinfo();

        System.out.println();
        System.out.println("_________MEMPOOL INFO_________");
        PrintTransactionQueue();

        System.out.println();
        System.out.println("_________BLOCK INFO_________");
        PrintBlockInfo();


        ProofSending();
        System.out.println("Pending proofs of E : " + E.pending_proofs.size());

        E.VerifyProof(E.pending_proofs.get(0));

        System.out.println("Pending proofs of E : " + E.pending_proofs.size());

        E.VerifyProof(E.pending_proofs.get(0));

        System.out.println("Pending proofs of E : " + E.pending_proofs.size());





        // If a transaction is initialised but not mined yet its in inprocess_transaction of Sender and global tx_queue
        // If a transaction is in blockchain , sender(Buyer) store that inside finalised transactions
        // removed from inprocess_transaction
        // But those transactions are need to be proved to seller
        // Buyer send proof for each transaction to Seller and Seller verify that








    }
}