import NewCoinPackage.*;
import HelperClasses.Pair;

import java.util.ArrayList;

public class Moderator
 {
  int no_of_coins;

  public void initializeCoin(ArrayList<Members> members, int tr_count) {
   //Send coins to everyone ( create those trc )
   for(Members m : members){
    for(int i=1 ; i <= no_of_coins ; i++){
     String coin_id = String.format("%06d", Global_Data.last_coin_id);
     Global_Data.last_coin_id++;

     Transaction t = new Transaction(coin_id,null,m,null);
     Global_Data.tx_queue.add(t);
    }
   }
   //add all those transactions in some blocks

   int total_tx = Global_Data.tx_queue.size();
   int full_blocks = total_tx/tr_count;

   for(int x=0;x < full_blocks;x++)
   {
    Transaction[] trc = new Transaction[tr_count];
    for(int i=0;i<tr_count;i++)
    {
     trc[i]= Global_Data.tx_queue.get(0);
     Global_Data.tx_queue.remove(0);
    }
    if(Global_Data.block_chain.size()==0)
    {
     TransactionBlock new_block = new TransactionBlock(trc,null);
     Global_Data.block_chain.add(new_block);
     Global_Data.last_block_dgst = new_block.dgst;
    }
    else
    {
     TransactionBlock last_block = Global_Data.block_chain.get(Global_Data.block_chain.size()-1);
     TransactionBlock new_block = new TransactionBlock(trc, last_block);
     Global_Data.block_chain.add(new_block);
     Global_Data.last_block_dgst = new_block.dgst;
    }
   }
   // last one
   Transaction[] remaining = Global_Data.tx_queue.toArray(new Transaction[0]); // Arraylist -> Array
   Global_Data.tx_queue.clear();
   TransactionBlock last_block = Global_Data.block_chain.get(Global_Data.block_chain.size()-1);
   TransactionBlock new_block = new TransactionBlock(remaining, last_block);
   Global_Data.block_chain.add(new_block);
   Global_Data.last_block_dgst = new_block.dgst;

   //add the pair < coin_id , respective_block > to respective member's mycoins

   for(TransactionBlock blk : Global_Data.block_chain){
    for(Transaction trc : blk.trarray){
     String t_coin_id = trc.coinID;
     Members t_dest = trc.Destination;

     Pair<String,TransactionBlock> p = new Pair<>(t_coin_id,blk);
     t_dest.mycoins.add(p);

    }
   }

  }
}
