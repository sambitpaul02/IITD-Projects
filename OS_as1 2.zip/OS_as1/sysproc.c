#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "history.h"
#include "syscall.h" 


extern int (*syscalls[])(void);


// -------------------------------------------------------------------->

int
sys_gethistory(void) {
    char *user_entries; // User-space address of entries array
    int max_entries;
    struct history_entry temp_history[MAX_HISTORY];
    int i, j, num_entries;

    // Fetch user-space pointer and max_entries
    if (argptr(0, &user_entries, 1) < 0 || argint(1, &max_entries) < 0) {
        return -1;
    }

    // Convert to kernel-space pointer for arithmetic
    struct history_entry *entries = (struct history_entry *)user_entries;

    acquire(&history_lock);
    num_entries = history_count;
    for (i = 0; i < num_entries; i++) {
        temp_history[i] = history[i];
    }

    // Sort by start_ticks (bubble sort)
    for (i = 0; i < num_entries - 1; i++) {
        for (j = 0; j < num_entries - i - 1; j++) {
            if (temp_history[j].start_ticks > temp_history[j+1].start_ticks) {
                struct history_entry tmp = temp_history[j];
                temp_history[j] = temp_history[j+1];
                temp_history[j+1] = tmp;
            }
        }
    }

    int to_copy = (max_entries < num_entries) ? max_entries : num_entries;
    for (i = 0; i < to_copy; i++) {
        // Calculate user-space address correctly
        // uint addr = (uint)(user_entries + i * sizeof(struct history_entry));
        uint addr = (uint)( entries + i );
        if (copyout(myproc()->pgdir, addr, (char*)&temp_history[i], sizeof(struct history_entry)) < 0) {
            release(&history_lock);
            return -1;
        }
    }

    release(&history_lock);
    return to_copy;
}

// -------------------------------------------------------------------------------------------------------------------->

int sys_block(void) {
  int syscall_id;
  if (argint(0, &syscall_id) < 0) return -1;

  // Critical syscalls: fork (1), exit (2)
  if (syscall_id == 1 || syscall_id == 2) return -1;

  // Validate syscall_id
  // if (syscall_id < 1 || syscall_id >= NELEM(syscalls) || !syscalls[syscall_id]) 
   // return -1;

  struct proc *curproc = myproc();
  curproc->blocked_syscalls |= (1 << syscall_id); // Block the syscall
  return 0;
}

int sys_unblock(void) {
  int syscall_id;
  if (argint(0, &syscall_id) < 0) return -1;

  // Validate syscall_id
  //if (syscall_id < 1 || syscall_id >= NELEM(syscalls) || !syscalls[syscall_id]) 
   // return -1;

  struct proc *curproc = myproc();
  curproc->blocked_syscalls &= ~(1 << syscall_id); // Unblock the syscall
  return 0;
}

//-------------------------------------------------------------------------------------------------------------------->

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
