#ifndef HISTORY_H
#define HISTORY_H

// Define the history_entry structure
struct history_entry {
  int pid;
  char name[16];
  uint sz;
  uint start_ticks;
};

// Declare the maximum history size as a macro
#define MAX_HISTORY 100

// Declare extern variables (defined in proc.c)
extern struct spinlock history_lock;
extern struct history_entry history[];
extern int history_count;

#endif
