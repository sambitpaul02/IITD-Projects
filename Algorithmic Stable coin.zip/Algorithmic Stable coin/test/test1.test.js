const DSCEngine = artifacts.require("DSCEngine");
const DSC = artifacts.require("DecentralizedStableCoin");
const MockV3Aggregator = artifacts.require("MockV3Aggregator");
const WETH = artifacts.require("WETH");

contract("DSCEngine", (accounts) => {
    let dscEngine, dsc, mockAggregator, weth;
    const [deployer, user1, user2,user3,user4] = accounts;
    console.log("------------------------- TEST STARTED -------------------------");
    console.log("--------------==---------------")
    console.log("Deployer = ", deployer);
    console.log("User 1 = ", user1);
    console.log("User 2 = ", user2);
    console.log("User 3 = ", user3);
    console.log("User 4 = ", user4);
    console.log("--------------==---------------\n")

    before(async () => {
        console.log("--------------DEPLOYED---------------")
        dscEngine = await DSCEngine.deployed();
        dsc = await DSC.deployed();
        mockAggregator = await MockV3Aggregator.deployed();
        weth = await WETH.deployed();
        const ownershipchange = await dsc.transferOwnership(dscEngine.address, {from : deployer});

        console.log(`Ownership of DSC transferred to dscEngine contract`);

        console.log("--------------DEPLOYED---------------\n")

    });




    console.log("--------------Test 1--------------")
    it("Deploys Contract Successfully", async () => {
        assert(dscEngine.address !== "");
        assert(dsc.address !== "");
        assert(mockAggregator.address !== "");
        assert(weth.address !== "");
        jsonf = {
            "dscEngine.address":dscEngine.address,"dsc.address": dsc.address, "mockAggregator.address":mockAggregator.address, "weth.address":weth.address
        }
        // console.log("Address:", jsonf);
    });

    // console.log("--------------==--------------\n")
    //
    // console.log("--------------Test 2--------------")
    // it("should interact with the DSCEngine", async () => {
    //     const depositAmount = 50;
    //     // let depositAmount = web3.utils.toWei("50", "ether");
    //     const mintAmount = 25;
    //     // let mintAmount = web3.utils.toWei("25", "ether");
    //
    //     console.log("depositAmount = ", depositAmount)
    //
    //     const deposit_return = await dscEngine.depositCollateralAndMintDsc(weth.address, depositAmount, mintAmount,{ from: user1 });
    //     // console.log("deposit_return = ", deposit_return)
    //
    //     // const deposit_return1 = await dscEngine.depositCollateral(weth.address,depositAmount ,{ from: user1 });
    //     // console.log("deposit_return1 = ", deposit_return1)
    //     //
    //     //
    //     // const deposit_return2 = await dscEngine.mintDsc(mintAmount,{ from: user1 });
    //     // console.log("deposit_return2 = ", deposit_return2)
    //
    //
    //     const depositedBalance = await dscEngine.getCollateralBalanceOfUser(user1);
    //     const blstring = parseInt(depositedBalance.toString())
    //     console.log(`userCollAmt[user1] = `, blstring, ` (Deposited WETH)`)
    //
    //     const debt = await dscEngine.getAccountDebtValue(user1);
    //     const debtstring = parseInt(debt.toString())
    //     console.log(`userDebt[user1] = `, debtstring, ` (DSC Coins)`)
    //
    //     const a = await dscEngine.getUsdValue(depositAmount);
    //     const a1 = parseInt(a.toString())
    //     console.log(`a1 = `, a1, ` ()`)
    //
    //     // const redeemCollateralForDsc = await dscEngine.redeemCollateralForDsc(weth.address, 10, 10);
    //     // const redeemCollateralString = parseInt(redeemCollateralForDsc.toString())
    //     // console.log(`redeemCollateralString = `, redeemCollateralString, ``)
    //
    //
    //
    //
    //     assert.equal(
    //         blstring,
    //         depositAmount,
    //         "Deposit function failed"
    //     );
    // });
    //
    // console.log("--------------==---------------\n")
    //
    //
    // console.log("--------------Test 2--------------")
    it("Allows To Deposit Amount And Update Balance", async () => {
        const depositAmount = 50;
        const mintAmount = 25;
        await dscEngine.depositCollateralAndMintDsc(weth.address, depositAmount, mintAmount,{ from: user2 });
        const depositedBalance = await dscEngine.getCollateralBalanceOfUser(user2);
        const blstring = parseInt(depositedBalance.toString())

        assert.equal(
            blstring,
            depositAmount,
            `Deposit function failed (${blstring} != ${depositAmount})`
        );
    });

    it("Allows To Redeem Amount And Update Balance", async () => {
        const depositAmount = 50;
        const mintAmount = 25;
        await dscEngine.depositCollateralAndMintDsc(weth.address, depositAmount, mintAmount,{ from: user3 });

        const withdrawAmount = 10;
        const burnAmount = 25;

        let depositedBalance = await dscEngine.getCollateralBalanceOfUser(user3);
        let blstring = parseInt(depositedBalance.toString())
        // console.log(`userColl[user3] = `, blstring, ` (DSC Coins)`)
        let debt = await dscEngine.getAccountDebtValue(user3);
        let debtstring = parseInt(debt.toString())
        // console.log(`userDebt[user3] = `, debtstring, ` ()`)

        const redeemCollateralForDsc = await dscEngine.redeemCollateralForDsc(weth.address, withdrawAmount, burnAmount ,{ from: user3});

        depositedBalance = await dscEngine.getCollateralBalanceOfUser(user3);
        blstring = parseInt(depositedBalance.toString())
        // console.log(`userColl[user3] = `, blstring, ` (DSC Coins)`)
        debt = await dscEngine.getAccountDebtValue(user3);
        debtstring = parseInt(debt.toString())
        // console.log(`userDebt[user3] = `, debtstring, ` ()`)

        assert.equal(
            blstring ,
            depositAmount-withdrawAmount,
            `Deposit Unstable`
        );
        assert.equal(
            debtstring ,
            mintAmount-burnAmount,
            `Burn Unstable`
        );
    });


    it("Allows To Liquidate", async () => {
        try {

            const depositAmount = 25;
            const mintAmount = 10;
            await dscEngine.depositCollateralAndMintDsc(weth.address, depositAmount, mintAmount, {from: user4});


            let depositedBalance = await dscEngine.getCollateralBalanceOfUser(user4);
            let blstring = parseInt(depositedBalance.toString())
            // console.log(`userColl[user3] = `, blstring, ` (DSC Coins)`)
            let debt = await dscEngine.getAccountDebtValue(user3);
            let debtstring = parseInt(debt.toString())
            // console.log(`userDebt[user3] = `, debtstring, ` ()`)
            //

            let tokens_to_burn = 5;
            let liquidate = await dscEngine.liquidate(weth.address, user4, tokens_to_burn, {from: user4});

            depositedBalance = await dscEngine.getCollateralBalanceOfUser(user4);
            blstring = parseInt(depositedBalance.toString())
            // console.log(`userColl[user3] = `, blstring, ` (DSC Coins)`)
            debt = await dscEngine.getAccountDebtValue(user3);
            debtstring = parseInt(debt.toString())
            // console.log(`userDebt[user3] = `, debtstring, ` ()`)

            assert.equal(
                50,
                1,
                "Error"
            );
        }catch (error) {
            assert.equal(
                1,
                1,
                "Error"
            );
        }
    });


    it("Health Factor Greater Than 1", async () => {
        try {

            const depositAmount = 25;
            const mintAmount = 10;
            await dscEngine.depositCollateralAndMintDsc(weth.address, depositAmount, mintAmount, {from: user4});


            let depositedBalance = await dscEngine.getCollateralBalanceOfUser(user4);
            let blstring = parseInt(depositedBalance.toString())
            // console.log(`userColl[user3] = `, blstring, ` (DSC Coins)`)
            let debt = await dscEngine.getAccountDebtValue(user3);
            let debtstring = parseInt(debt.toString())
            // console.log(`userDebt[user3] = `, debtstring, ` ()`)
            //

            let health_factor = await dscEngine.getHealthFactor( user4, {from: user4});

            assert.equal(
                1,
                1,
                "Error"
            );
        }catch (error) {
            assert.equal(
                20,
                1,
                "Error"
            );
        }
    });

    console.log("--------------==---------------\n")



    // it("should allow minting of DSC", async () => {
    //     // Mint DSC tokens for user1
    //     const amount = web3.utils.toWei("100", "ether");
    //     await dsc.mint(user1, amount, { from: deployer });
    //
    //     // Check balance
    //     const balance = await dsc.balanceOf(user1);
    //     assert.equal(balance.toString(), amount, "Minting failed");
    // });

    // it("should interact with the DSCEngine", async () => {
    //     // Example interaction with DSCEngine
    //     const depositAmount = web3.utils.toWei("50", "ether");
    //
    //     // Approve DSCEngine to use user's DSC
    //     await dsc.approve(dscEngine.address, depositAmount, { from: user1 });
    //
    //     // Call deposit function in DSCEngine
    //     await dscEngine.deposit(depositAmount, { from: user1 });
    //
    //     // Verify the deposited balance
    //     const depositedBalance = await dscEngine.getDepositedBalance(user1);
    //     assert.equal(
    //         depositedBalance.toString(),
    //         depositAmount,
    //         "Deposit function failed"
    //     );
    // });

    // it("should handle price feeds", async () => {
    //     // Interact with MockV3Aggregator
    //     const price = await mockAggregator.latestAnswer();
    //     console.log(`Mock Aggregator Price: ${price.toString()}`);
    //     assert(price.toNumber() > 0, "Price feed not working");
    // });

    // it("should interact with WETH", async () => {
    //     const mintAmount = web3.utils.toWei("10", "ether");
    //
    //     // Mint WETH for user2
    //     await weth.deposit({ from: user2, value: mintAmount });
    //
    //     // Check WETH balance
    //     const wethBalance = await weth.balanceOf(user2);
    //     assert.equal(
    //         wethBalance.toString(),
    //         mintAmount,
    //         "WETH minting failed"
    //     );
    // });

});
