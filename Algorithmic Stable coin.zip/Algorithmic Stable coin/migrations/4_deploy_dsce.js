const OracleLib = artifacts.require("OracleLib");
const DSCEngine = artifacts.require("DSCEngine");
const MockV3Aggregator = artifacts.require("MockV3Aggregator");
const DecentralizedStableCoin = artifacts.require("DecentralizedStableCoin");
const WETH = artifacts.require("WETH");

module.exports = async function (deployer, network, accounts) {
  const owner = accounts[0]; // Deployer account

  // Deploy OracleLib
  await deployer.deploy(OracleLib);
  const oracleLib = await OracleLib.deployed();

  // Link OracleLib to DSCEngine
  deployer.link(OracleLib, DSCEngine);

  // Retrieve already deployed contracts
  const priceFeed = await MockV3Aggregator.deployed();
  const dsc = await DecentralizedStableCoin.deployed();
  const weth = await WETH.deployed();

  // Deploy DSCEngine with updated parameters
  const instance = await deployer.deploy(DSCEngine, weth.address, priceFeed.address, dsc.address, { from: owner });


  console.log("DSCEngine Address:", instance.address);

  console.log("OracleLib deployed at:", oracleLib.address);
  console.log("WETH address:", weth.address);
  console.log("DSCEngine deployed successfully.");

};
