const DecentralizedStableCoin = artifacts.require("DecentralizedStableCoin");

module.exports = function (deployer) {
  deployer.deploy(DecentralizedStableCoin);
};
