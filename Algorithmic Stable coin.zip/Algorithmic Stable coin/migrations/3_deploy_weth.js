const WETH = artifacts.require("WETH");

module.exports = async function (deployer, network, accounts) {
  await deployer.deploy(WETH);
  const weth = await WETH.deployed();
  console.log("WETH deployed at:", weth.address);
};
