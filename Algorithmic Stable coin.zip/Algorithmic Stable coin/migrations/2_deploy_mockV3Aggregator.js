const MockV3Aggregator = artifacts.require("MockV3Aggregator");

module.exports = function (deployer) {
  const decimals = 8;
  const initialPrice = web3.utils.toWei("2000", "ether"); // Mock price feed value
  deployer.deploy(MockV3Aggregator, decimals, initialPrice);
};
