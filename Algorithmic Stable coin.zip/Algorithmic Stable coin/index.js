const express = require('express');
const Web3 = require('web3');
const path = require('path');

const app = express();
const port = 3000;

// Connect to Ganache
const web3 = new Web3('http://127.0.0.1:8545');

// Load Contract ABI and Address
const dscEngineABI = require('./build/contracts/DSCEngine.json').abi; // Adjust path if necessary
const contractAddress = '0xYourDeployedContractAddress'; // Replace with deployed address

// Create Contract Instance
const dscEngineContract = new web3.eth.Contract(dscEngineABI, contractAddress);

// Serve Static Frontend Files
app.use(express.static(path.join(__dirname, 'frontend')));

// API Route: Get Total Supply
app.get('/api/totalSupply', async (req, res) => {
    try {
        const totalSupply = await dscEngineContract.methods.totalSupply().call();
        res.json({ totalSupply });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Failed to fetch total supply' });
    }
});

// Start the Server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
