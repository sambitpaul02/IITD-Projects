import os

def list_files_upto_level2(base_path):
    for root, dirs, files in os.walk(base_path):
        # Calculate the current depth of traversal
        depth = root[len(base_path):].count(os.sep)
        if depth > 1:
            continue

        indent = "  " * depth
        print(f"{indent}-- {os.path.basename(root) if depth > 0 else root}")

        for name in files:
            print(f"{indent}  - {name}")

        # Stop further traversal beyond level 2
        if depth == 1:
            del dirs[:]

# Example usage
base_directory = "."  # Replace "." with your base directory path
list_files_upto_level2(base_directory)
