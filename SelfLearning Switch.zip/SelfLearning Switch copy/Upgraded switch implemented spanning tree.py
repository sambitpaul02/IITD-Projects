from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.topology.api import get_switch, get_link , get_host
from collections import deque
from ryu.lib.packet import ether_types
from ryu.topology import switches , event
import eventlet
import copy


class SpanningTreeSwitch(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]
    _CONTEXTS = {
        'switches': switches.Switches,
    }

    def __init__(self, *args, **kwargs):
        super(SpanningTreeSwitch, self).__init__(*args, **kwargs)
        self.mac_to_port = {}
        self.switches = {}  # {dpid: datapath}
        self.net = {}  # Dictionary for network topology as adjacency list
        self.root_switch = None
        self.spanning_tree_ports = {}  # {dpid: [ports]} - Ports part of the spanning tree
        self.topo_links = []
        self.spt_links = []
        self.hosts = []
        self.max_links = 0

    # Function to add flow to the switch flow table
    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        switch_id = datapath.id

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]

        if buffer_id:
            msg = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match,
                                    instructions=inst)
        else:
            msg = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, instructions=inst)
        datapath.send_msg(msg)

    @set_ev_cls(event.EventHostAdd, MAIN_DISPATCHER)
    def handler_host_add(self, ev):
        host = ev.host
        self.hosts.append(host)
        print("Host Appended _____________________>>")
        print(f" This host is Connected to switch : {host.port.dpid} , in PORT : {host.port.port_no}")
        print(f"No of hosts : {len(self.hosts)} ")

        if host.port.dpid not in self.spanning_tree_ports:
            self.spanning_tree_ports[host.port.dpid] = []
        if host.port.port_no not in self.spanning_tree_ports[host.port.dpid]:
            self.spanning_tree_ports[host.port.dpid].append(host.port.port_no)
        print("I am now ready ------>>>>")
        self.printSPT()



    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev): # Triggered when a switch is connected to the controller 
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions) # Default flow set in the switch 

        # Add the switch to the topology and discover links
        self.switches[datapath.id] = datapath
        self.logger.info("Switch %s connected", datapath.id)


        eventlet.sleep(5)

        if(len(self.topo_links)>=self.max_links): # Ensure all the links are stored 
            self.topo_links = copy.copy(get_link(self, None))
            print(f"No of links : {len(self.topo_links)} ")
            self.max_links = len(self.topo_links)


        self.discover_topology()

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):

        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']
        switch_id = datapath.id

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]
        dst = eth.dst
        src = eth.src

        self.mac_to_port.setdefault(switch_id, {})
        if src not in self.mac_to_port[switch_id]:
            self.mac_to_port[switch_id][src] = in_port

        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        out_port = self.mac_to_port[switch_id].get(dst, ofproto.OFPP_FLOOD)

        if out_port == ofproto.OFPP_FLOOD:
            spanning_ports = self.spanning_tree_ports.get(switch_id, [])
            if spanning_ports:
                actions = [parser.OFPActionOutput(port) for port in spanning_ports]
                data = msg.data if msg.buffer_id == ofproto.OFP_NO_BUFFER else None
                out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                          in_port=in_port, actions=actions, data=data)
                datapath.send_msg(out)
            else:
                actions = [parser.OFPActionOutput(ofproto.OFPP_FLOOD)]
                out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                          in_port=in_port, actions=actions, data=None)
                datapath.send_msg(out)
        else:
            actions = [parser.OFPActionOutput(out_port)]
            match = parser.OFPMatch(in_port=in_port, eth_dst=dst, eth_src=src)

            if msg.buffer_id != ofproto.OFP_NO_BUFFER:
                self.add_flow(datapath, 1, match, actions, msg.buffer_id)
                return

            self.add_flow(datapath, 1, match, actions)

            data = msg.data if msg.buffer_id == ofproto.OFP_NO_BUFFER else None
            out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                      in_port=in_port, actions=actions, data=data)
            datapath.send_msg(out)

    def discover_topology(self):
        self.build_graph()
        self.assign_root_switch()
        self.build_spanning_tree()
        self.printSPT()

    def build_graph(self):
        #  Build a graph using an adjacency list

        self.net.clear()  # Clear the current graph

        for link in self.topo_links:
            src_dpid = link.src.dpid
            dst_dpid = link.dst.dpid

            print(f"src : {src_dpid} , dst : {dst_dpid} , SrcToDstPort : {link.src.port_no} , DstToSrcPort : {link.dst.port_no}")

            # Add adjacents of the switches in the adjacency list (net)
            if src_dpid not in self.net:
                self.net[src_dpid] = set()
            if dst_dpid not in self.net:
                self.net[dst_dpid] = set()
            self.net[src_dpid].add(dst_dpid)
            self.net[dst_dpid].add(src_dpid)

    def assign_root_switch(self):
        switch_ids = list(self.switches.keys())
        if switch_ids:
            self.root_switch = min(switch_ids)
            print(f'Root switch : {self.root_switch}')

    def build_spanning_tree(self):
        #  Use BFS to build the spanning tree starting from the root switch
        if self.root_switch is None:
            self.logger.error("Root switch is not assigned.")
            return

        visited = set()
        queue = deque([self.root_switch])
        self.spanning_tree_ports.clear()  # Clear previous spanning tree # Basically refreshing
        self.spt_links.clear()

        while queue:
            switch = queue.popleft()
            if switch not in visited:
                visited.add(switch)

            for neighbor in self.net.get(switch, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    if neighbor not in queue :
                        queue.append(neighbor)

                    for link in self.topo_links:
                        if link.src.dpid == switch :
                            if link.dst.dpid == neighbor :
                                self.spt_links.append(link)


        print(f"#links in SPT : {len(self.spt_links)}")

        for l in self.spt_links:
            source = l.src
            destination = l.dst
            if source.dpid not in self.spanning_tree_ports:
                self.spanning_tree_ports[source.dpid] = []
            if destination.dpid not in self.spanning_tree_ports:
                self.spanning_tree_ports[destination.dpid] = []

            if source.port_no not in self.spanning_tree_ports[source.dpid]:
                self.spanning_tree_ports[source.dpid].append(source.port_no)
            if destination.port_no not in self.spanning_tree_ports[destination.dpid]:
                self.spanning_tree_ports[destination.dpid].append(destination.port_no)

        print("Spanning tree Created ")


    def printSPT(self):
        for switch, ports in self.spanning_tree_ports.items():
            print(f"Switch : {switch} , PORTs : {ports}")
