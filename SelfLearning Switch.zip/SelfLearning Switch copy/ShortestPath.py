from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import ether_types
from collections import deque
from ryu.topology import event
from ryu.topology.api import get_switch, get_link

class ShortestPathSwitch13(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(ShortestPathSwitch13, self).__init__(*args, **kwargs)
        self.mac_to_port_mapping = {}
        self.mac_to_switch_info = {}
        self.network_topology = {}

    def get_shortest_path_port(self, src_dpid, dst_dpid):
        visited = {src_dpid}
        queue = deque()
        previous = {}
        queue.append(src_dpid)
        while queue:
            current_dpid = queue.popleft()
            if current_dpid == dst_dpid:
                break
            for neighbor in self.network_topology.get(current_dpid, {}):
                if neighbor not in visited:
                    visited.add(neighbor)
                    previous[neighbor] = current_dpid
                    queue.append(neighbor)
        else:
            return None
        path = []
        dpid = dst_dpid
        while dpid != src_dpid:
            path.append(dpid)
            dpid = previous[dpid]
        path.append(src_dpid)
        path.reverse()
        if len(path) > 1:
            next_hop = path[1]
            out_port = self.network_topology[src_dpid][next_hop]
            return out_port
        else:
            return None

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def features_handler(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self.install_flow(datapath, 0, match, actions)

    def install_flow(self, datapath, priority, match, actions):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        instructions = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS,
                                                     actions)]
        flow_mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                     match=match, instructions=instructions)
        datapath.send_msg(flow_mod)

    @set_ev_cls(event.EventSwitchEnter)
    def handle_switch_enter(self, ev):
        switch = ev.switch
        dpid = switch.dp.id
        self.network_topology.setdefault(dpid, {})

    @set_ev_cls(event.EventLinkAdd)
    def handle_link_add(self, ev):
        src_dpid = ev.link.src.dpid
        dst_dpid = ev.link.dst.dpid
        src_port = ev.link.src.port_no
        self.network_topology.setdefault(src_dpid, {})
        self.network_topology[src_dpid][dst_dpid] = src_port
        dst_port = ev.link.dst.port_no
        self.network_topology.setdefault(dst_dpid, {})
        self.network_topology[dst_dpid][src_dpid] = dst_port

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        ingress_port = msg.match['in_port']
        pkt = packet.Packet(msg.data)
        eth_frame = pkt.get_protocols(ethernet.ethernet)[0]
        if eth_frame.ethertype == ether_types.ETH_TYPE_LLDP:
            return
        dst_mac = eth_frame.dst
        src_mac = eth_frame.src
        dpid = datapath.id
        self.mac_to_port_mapping.setdefault(dpid, {})
        self.mac_to_port_mapping[dpid][src_mac] = ingress_port
        self.mac_to_switch_info[src_mac] = (dpid, ingress_port)
        print(f"Packet Received. Switch={dpid} src={src_mac} dst={dst_mac} inport={ingress_port}")
        if dst_mac in self.mac_to_switch_info:
            dst_dpid, dst_port = self.mac_to_switch_info[dst_mac]
            if dst_dpid == dpid:
                out_port = dst_port
            else:
                out_port = self.get_shortest_path_port(dpid, dst_dpid)
                if out_port is None:
                    out_port = ofproto.OFPP_FLOOD
        else:
            out_port = ofproto.OFPP_FLOOD
        actions = [parser.OFPActionOutput(out_port)]
        if out_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(eth_src=src_mac, eth_dst=dst_mac)
            self.install_flow(datapath, 1, match, actions)
            print(f"Flow added for switch={dpid}, inport={ingress_port}. Packet {src_mac}->{dst_mac}")
        data = None
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data
        packet_out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                         in_port=ingress_port, actions=actions, data=data)
        datapath.send_msg(packet_out)